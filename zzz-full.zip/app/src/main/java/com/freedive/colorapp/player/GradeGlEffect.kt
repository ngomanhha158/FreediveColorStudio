// ============================================================================
//  GRADE EFFECT — noi engine mau vao pipeline video cua Media3
//  GlEffect  : mo ta hieu ung, Media3 goi toGlShaderProgram() tren GL thread.
//  BaseGlShaderProgram : moi frame goi drawFrame(inputTexId, ptsUs).
//  Tham so lay tu GradeBus (UI ghi, GL doc) nen keo slider la thay ngay,
//  ke ca khi video dang TAM DUNG — Media3 ve lai frame hien tai.
//
//  Dung RawGlProgram thay GlProgram cua Media3: GlProgram bind moi uniform theo
//  bang kieu co san va KHONG biet sampler3D (LUT .cube), gap la nem
//  IllegalStateException lam sap ca pipeline (man hinh den).
// ============================================================================
package com.freedive.colorapp.player

import android.content.Context
import androidx.media3.common.VideoFrameProcessingException
import androidx.media3.common.util.Size
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.BaseGlShaderProgram
import androidx.media3.effect.GlEffect
import androidx.media3.effect.GlShaderProgram
import android.opengl.GLES30
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * [params] / [lutPath] / [wipe] duoc lay qua ham chu KHONG doc thang GradeBus:
 * khi XUAT HANG LOAT, moi clip phai dung grade CUA CHINH NO, khong phai grade
 * dang hien tren man hinh. Mac dinh van la GradeBus (dung cho preview).
 */
@UnstableApi
class GradeGlEffect(
    private val params: () -> FloatArray = { GradeBus.params },
    private val lutPath: () -> String = { GradeBus.lutPath },
    private val wipe: () -> Float = { GradeBus.wipeX },
    private val zebra: () -> Boolean = { GradeBus.zebra },
) : GlEffect {
    override fun toGlShaderProgram(context: Context, useHdr: Boolean): GlShaderProgram =
        GradeShaderProgram(context, useHdr, params, lutPath, wipe, zebra)
}

@UnstableApi
class GradeShaderProgram(
    context: Context,
    useHdr: Boolean,
    private val paramsOf: () -> FloatArray,
    private val lutPathOf: () -> String,
    private val wipeOf: () -> Float,
    private val zebraOf: () -> Boolean,
) : BaseGlShaderProgram(useHdr, /* texturePoolCapacity= */ 1) {

    private companion object {
        const val VERTEX = "shaders/gl/grade_vertex.glsl"
        const val FRAGMENT = "shaders/gl/grade_fragment.glsl"
        const val INPUT_UNIT = 0
        const val LUT_UNIT = 1
    }

    private val program: RawGlProgram = try {
        RawGlProgram(
            context.assets.open(VERTEX).bufferedReader().use { it.readText() },
            context.assets.open(FRAGMENT).bufferedReader().use { it.readText() },
        )
    } catch (e: Exception) {
        // Bao loi ra ngoai de MainActivity hien thi thay vi man hinh den im lang
        GlStatus.report("Grade shader: ${e.message}")
        throw VideoFrameProcessingException(e)
    }

    private var lutTexId = 0
    private var lutSize = 0f
    private var loadedLutPath = ""

    override fun configure(inputWidth: Int, inputHeight: Int): Size = Size(inputWidth, inputHeight)

    override fun drawFrame(inputTexId: Int, presentationTimeUs: Long) {
        val p = paramsOf()
        try {
            program.use()
            ensureLut(lutPathOf())
            program.setTexture2D("uTexSampler", inputTexId, INPUT_UNIT)

            // ---- Layer 1 ----
            program.setFloat("uTemp", p[GradeBus.I.TEMP])
            program.setFloat("uTint", p[GradeBus.I.TINT])
            program.setFloat("uEv", p[GradeBus.I.EV])
            program.setFloat("uContrast", p[GradeBus.I.CONTRAST])
            program.setFloat("uShadows", p[GradeBus.I.SHADOWS])
            program.setFloat("uHighlights", p[GradeBus.I.HIGHLIGHTS])
            program.setFloat("uRedRecovery", p[GradeBus.I.RED_RECOVERY])
            program.setFloat("uAntiGreen", p[GradeBus.I.ANTI_GREEN])
            program.setFloat("uMagentaGuard", p[GradeBus.I.MAGENTA_GUARD])
            program.setFloat("uL1On", p[GradeBus.I.L1_ON])

            // ---- Layer 2 ----
            val lutOn = if (lutTexId != 0) p[GradeBus.I.L2_ON] else 0f
            program.setFloat("uLutIntensity", p[GradeBus.I.LUT_INTENSITY])
            program.setFloat("uLutSize", lutSize)
            program.setFloat("uL2On", lutOn)
            program.setFloat("uLumaProtect", p[GradeBus.I.LUMA_PROTECT])
            if (lutTexId != 0) program.setTexture3D("uLutTex", lutTexId, LUT_UNIT)

            // ---- Layer 3 ----
            val h = GradeBus.I.HSL_BASE
            program.setVec3("uHsl0", p[h], p[h + 1], p[h + 2])
            program.setVec3("uHsl1", p[h + 3], p[h + 4], p[h + 5])
            program.setVec3("uHsl2", p[h + 6], p[h + 7], p[h + 8])
            program.setVec3("uHsl3", p[h + 9], p[h + 10], p[h + 11])
            program.setVec3("uHsl4", p[h + 12], p[h + 13], p[h + 14])
            program.setVec3("uHsl5", p[h + 15], p[h + 16], p[h + 17])
            program.setVec3("uHsl6", p[h + 18], p[h + 19], p[h + 20])
            program.setFloat("uGlobalSat", p[GradeBus.I.GLOBAL_SAT])
            program.setFloat("uSkinProtect", p[GradeBus.I.SKIN_PROTECT])
            program.setFloat("uL3On", p[GradeBus.I.L3_ON])
            program.setVec3("uShadowTint",
                p[GradeBus.I.SHADOW_TINT_R], p[GradeBus.I.SHADOW_TINT_G], p[GradeBus.I.SHADOW_TINT_B])
            program.setVec4("uSkinMask",
                p[GradeBus.I.SKIN_HUE], p[GradeBus.I.SKIN_TOL],
                p[GradeBus.I.SKIN_FEATHER], p[GradeBus.I.SKIN_STRENGTH])
            program.setVec4("uSkinMask2",
                p[GradeBus.I.SKIN_ENABLE], p[GradeBus.I.SKIN_MASK_VIEW], 0.12f, 0.15f)

            // So sanh Before/After — vi tri thanh truot
            program.setFloat("uWipeX", wipeOf())

            // Zebras: dung dong ho he thong (khong dung pts) de soc van chay
            // khi video dang tam dung — luc do moi la luc soi phoi sang ky nhat.
            program.setFloat("uZebra", if (zebraOf()) 1f else 0f)
            program.setFloat("uTime", android.os.SystemClock.uptimeMillis() % 100000L / 1000f)

            program.drawQuad()
        } catch (e: Exception) {
            GlStatus.report("Grade drawFrame: ${e.message}")
            throw VideoFrameProcessingException(e, presentationTimeUs)
        }
    }

    /** Nap lai texture 3D khi nguoi dung doi LUT */
    private fun ensureLut(path: String) {
        if (path == loadedLutPath) return
        loadedLutPath = path
        deleteLutTexture()
        if (path.isEmpty()) { lutSize = 0f; return }

        val lut = CubeLutParser.parse(path)
        if (lut == null) { lutSize = 0f; return }

        val ids = IntArray(1)
        GLES30.glGenTextures(1, ids, 0)
        val id = ids[0]
        GLES30.glBindTexture(GLES30.GL_TEXTURE_3D, id)
        // NEAREST: shader tu noi suy tu dien, khong de phan cung trilinear can thiep
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_3D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_NEAREST)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_3D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_NEAREST)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_3D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_3D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_3D, GLES30.GL_TEXTURE_WRAP_R, GLES30.GL_CLAMP_TO_EDGE)

        val bb = ByteBuffer.allocateDirect(lut.rgb.size * 4).order(ByteOrder.nativeOrder())
        bb.asFloatBuffer().put(lut.rgb)
        bb.rewind()
        GLES30.glTexImage3D(
            GLES30.GL_TEXTURE_3D, /* level= */ 0, GLES30.GL_RGB16F,
            lut.size, lut.size, lut.size, /* border= */ 0,
            GLES30.GL_RGB, GLES30.GL_FLOAT, bb
        )
        lutTexId = id
        lutSize = lut.size.toFloat()
    }

    private fun deleteLutTexture() {
        if (lutTexId != 0) {
            GLES30.glDeleteTextures(1, intArrayOf(lutTexId), 0)
            lutTexId = 0
        }
    }

    override fun release() {
        super.release()
        deleteLutTexture()
        program.release()
    }
}
