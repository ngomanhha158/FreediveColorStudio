#version 300 es
// ============================================================================
//  FREEDIVE COLOR — PASS GRADE (GL ES 3.0)
//  Ban port cua 3 pass Vulkan goc, GOP LAM MOT vi ca ba deu thuan tuy per-pixel:
//      color_space.frag     (CST D-Log M -> Rec.709 + Layer 1)
//    + lut_tetrahedral.frag (Layer 2 — noi suy tu dien tren LUT 3D)
//    + post_lut.frag        (Layer 3 — HSL 7 kenh, Global Sat, Skin Lock Mask)
//  Clarity KHONG gop vao day: no can lay mau 8 diem lan can cua ANH DA GRADE,
//  neu gop se phai chay lai ca chuoi 9 lan/pixel. Clarity o effect rieng.
//
//  Khac biet so voi ban Vulkan:
//   · push_constant / UBO  -> uniform roi rac (GL ES khong co push constant)
//   · mang uniform vec4[7] -> 7 uniform vec3 rieng (GlProgram cua Media3
//     khong co setter cho mang vector)
//   · Cong thuc mau giu NGUYEN VEN 100% de anh xuat khong lech so voi ban cu.
// ============================================================================
precision highp float;
precision highp sampler3D;

uniform sampler2D uTexSampler;   // frame vao (Media3 da chuyen ve texture 2D thuong)
uniform sampler3D uLutTex;       // LUT .cube 33^3 / 65^3

// ---- Layer 1 ----
uniform float uTemp;
uniform float uTint;
uniform float uEv;
uniform float uContrast;
uniform float uShadows;
uniform float uHighlights;
uniform float uRedRecovery;
uniform float uAntiGreen;
uniform float uMagentaGuard;
uniform float uL1On;

// ---- Layer 2 ----
uniform float uLutIntensity;
uniform float uLutSize;
uniform float uL2On;

// ---- Layer 3 ----
uniform vec3  uHsl0;   // R   (hueDeg, sat, luma)
uniform vec3  uHsl1;   // O
uniform vec3  uHsl2;   // Y
uniform vec3  uHsl3;   // G
uniform vec3  uHsl4;   // C
uniform vec3  uHsl5;   // B
uniform vec3  uHsl6;   // M
uniform float uGlobalSat;
uniform float uSkinProtect;
uniform float uL3On;
uniform vec3  uShadowTint;
uniform vec4  uSkinMask;    // (targetHueDeg, toleranceDeg, featherDeg, strength)
uniform vec4  uSkinMask2;   // (enable, maskView, satGateLo, valGateLo)

// So sanh Before/After: pixel co x < uWipeX chi qua CST, khong grade.
// 0.0 = tat so sanh.
uniform float uWipeX;

// Bao ve vung sang khoi LUT (giu tia nang duoi nuoc)
uniform float uLumaProtect;
// Zebras: canh bao chay sang / bet den. uTime (giay) de ke soc chay.
uniform float uZebra;
uniform float uTime;
// 1 = tone map filmic AgX (mac dinh) · 0 = chuyen thang Rec.709 nhu cu
uniform float uFilmic;

in  vec2 vTexSamplingCoord;
out vec4 outColor;

const float HSL_WIDTH = 35.0;

float luma709(vec3 c) { return dot(c, vec3(0.2126, 0.7152, 0.0722)); }

// ---------------------------------------------------------------- LAYER 1 ---
/*
 * D-Log -> tuyen tinh, THEO WHITEPAPER "D-Log and D-Gamut of DJI Cinema Color
 * System" (DJI cong bo):
 *      x <= 0.14 : (x - 0.0929) / 6.025
 *      x  > 0.14 : (10^(3.89616x - 2.27752) - 0.0108) / 0.9892
 *
 * LUU Y THANH THAT: DJI KHONG cong bo cong thuc rieng cho D-Log M (ban rut gon
 * dung tren Mini/Air). Day la duong cong D-Log ap cho canh quay D-Log M — sat
 * hon nhieu so voi ham gamma xap xi truoc day, nhung van khong phai chinh xac
 * tuyet doi. Muon dung tuyet doi thi nap LUT chuyen doi chinh chu cua DJI vao
 * Layer 2.
 */
vec3 dlogMToLinear(vec3 c) {
    c = clamp(c, 0.0, 1.0);
    vec3 lo = (c - 0.0929) / 6.025;
    vec3 hi = (pow(vec3(10.0), 3.89616 * c - 2.27752) - 0.0108) / 0.9892;
    return max(mix(lo, hi, step(vec3(0.14), c)), 0.0);
}


// Khai bao truoc: dinh nghia nam BEN DUOI khoi AgX, nhung agxTonemap() phai
// goi den no. GLSL bat buoc khai bao truoc khi dung.
vec3 linearToRec709(vec3 c);

/* ============================================================================
 *  AgX TONE MAPPING
 *  Nguon: glsl-tone-map (dmnsgn) — tong hop tu cau hinh OCIO cua Blender,
 *  ToneMapper cua Filament (Google) va ma tran Rec.2020<->sRGB cua three.js.
 *  Ma tran + he so lay NGUYEN VAN, khong tu che.
 *
 *  Vi sao can: truoc day sau khi nhan Exposure/Contrast trong khong gian tuyen
 *  tinh, moi gia tri > 1.0 bi CAT PHANG o buoc chuyen sang Rec.709 — tia nang
 *  duoi nuoc thanh mang trang bet, mat ca sac do. AgX ep vao mot duong sigmoid
 *  co VAI (shoulder): vung sang doi mau dan thay vi dung dot, va giu duoc sac
 *  o cac mau bao hoa manh — dung cai ma canh quay duoi nuoc hay hong nhat.
 * ========================================================================= */
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
    0.6274, 0.0691, 0.0164,
    0.3293, 0.9195, 0.0880,
    0.0433, 0.0113, 0.8956
);
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
    1.6605, -0.1246, -0.0182,
   -0.5876,  1.1329, -0.1006,
   -0.0728, -0.0083,  1.1187
);
const mat3 AgXInsetMatrix = mat3(
    0.856627153315983, 0.137318972929847, 0.11189821299995,
    0.0951212405381588, 0.761241990602591, 0.0767994186031903,
    0.0482516061458583, 0.101439036467562, 0.811302368396859
);
const mat3 AgXOutsetMatrix = mat3(
    1.1271005818144368, -0.1413297634984383, -0.14132976349843826,
   -0.11060664309660323, 1.157823702216272, -0.11060664309660294,
   -0.016493938717834573, -0.016493938717834257, 1.2519364065950405
);
const float AgxMinEv = -12.47393;
const float AgxMaxEv = 4.026069;

/* Tra ve gia tri DA MA HOA hien thi (Rec.709), san sang xuat ra man hinh.
   [contrast] -1..+1 lai vao so mu cua duong cong (1.0 = trung tinh). */
vec3 agxTonemap(vec3 col, float contrast) {
    col = LINEAR_SRGB_TO_LINEAR_REC2020 * col;
    col = AgXInsetMatrix * col;
    col = max(col, 1e-10);                       // tranh log2(0)
    col = clamp(log2(col), AgxMinEv, AgxMaxEv);
    col = (col - AgxMinEv) / (AgxMaxEv - AgxMinEv);
    col = clamp(col, 0.0, 1.0);

    // Xap xi da thuc cua duong sigmoid AgX (sai so binh phuong 3.67e-06)
    vec3 x2 = col * col;
    vec3 x4 = x2 * x2;
    col = + 15.5   * x4 * x2
          - 40.14  * x4 * col
          + 31.96  * x4
          - 6.868  * x2 * col
          + 0.4298 * x2
          + 0.1191 * col
          - 0.00232;

    // ---- agxLook (ASC CDL) ----
    // AgX TRAN (khong co "look") cho anh NHAT — day la dac tinh da duoc ghi
    // nhan: Blender luon kem mot look mac dinh, three.js va Filament cung vay.
    // Thieu khau nay chinh la ly do preset cu bi "lech" khi bat AgX.
    // Cong thuc lay tu glsl-tone-map: pow(val*slope + offset, power) roi noi
    // suy quanh luma. slope/offset giu trung tinh; power = tuong phan;
    // sat = 1.2 (giua trung tinh 1.0 va "punchy" 1.4 cua ban goc).
    float p = clamp(1.0 + contrast * 0.35, 0.5, 2.0);
    col = pow(max(col, 0.0), vec3(p));
    float lookLuma = dot(col, vec3(0.2126, 0.7152, 0.0722));
    col = clamp(lookLuma + 1.2 * (col - lookLuma), 0.0, 1.0);

    col = AgXOutsetMatrix * col;
    col = pow(max(col, 0.0), vec3(2.2));         // -> tuyen tinh
    col = LINEAR_REC2020_TO_LINEAR_SRGB * col;
    col = clamp(col, 0.0, 1.0);
    return linearToRec709(col);                  // -> ma hoa hien thi
}

/*
 * Tuong phan xoay quanh TRUNG TINH 0.18 trong khong gian TUYEN TINH.
 * Nhan thang vao anh da gamma (cach cu, pivot 0.4353) lam vung toi bi be gay
 * va mau xin di; luy thua quanh 0.18 la duong thang trong he log-log — dung
 * cach cac phan mem grade chuyen nghiep xoay tuong phan.
 */
vec3 applyContrastLinear(vec3 lin, float amount) {
    if (abs(amount) < 0.001) return lin;
    float k = 1.0 + amount;
    vec3 x = max(lin, 1e-5);
    return pow(x / 0.18, vec3(k)) * 0.18;
}
vec3 linearToRec709(vec3 c) {
    c = max(c, vec3(0.0));
    return mix(c * 4.5, 1.099 * pow(c, vec3(0.45)) - 0.099, step(vec3(0.018), c));
}

vec3 applyLayer1(vec3 srcRgb) {
    vec3 lin = dlogMToLinear(srcRgb);
    if (uL1On < 0.5) {
        return clamp(linearToRec709(lin), 0.0, 1.0);
    }
    // 1. Exposure (linear)
    lin *= exp2(uEv);

    // 2. White Balance & Tint (guard chong nhieu magenta vung toi)
    float tintEff = uTint;
    if (uMagentaGuard > 0.5) tintEff *= smoothstep(0.0, 0.35, luma709(lin));
    lin.r *= 1.0 + 0.25 * uTemp;
    lin.b *= 1.0 - 0.25 * uTemp;
    lin.g *= 1.0 - 0.20 * tintEff;

    // 3. Anti-Green thich nghi, bao toan luma
    if (uAntiGreen > 0.001) {
        float y0 = luma709(lin);
        lin.g -= uAntiGreen * max(lin.g - max(lin.r, lin.b), 0.0);
        lin *= y0 / max(luma709(lin), 1e-5);
    }

    // 4. Red Channel Recovery — nuoc hap thu do manh nhat o vung toi/trung binh,
    //    con vung sang (tia nang) gan nhu khong mat do. Bu deu tay ca khung se
    //    lam tia nang bi am hong. Trong so giam theo do sang.
    float yLin = luma709(lin);
    float depthW = exp(-yLin * 2.5);
    float refR = dot(lin.gb, vec2(0.7, 0.3));
    lin.r += uRedRecovery * 0.6 * depthW * max(refR - lin.r, 0.0);

    // 5. Tone mapping -> Rec.709, roi Shadows/Highlights o khong gian hien thi
    vec3 c;
    if (uFilmic > 0.5) {
        c = agxTonemap(lin, uContrast);              // co vai, khong cat ngon
    } else {
        c = linearToRec709(applyContrastLinear(lin, uContrast));
    }
    float y = luma709(c);
    c += uShadows    * 0.25 * pow(1.0 - y, 2.0);
    c += uHighlights * 0.25 * pow(y, 2.0);
    return clamp(c, 0.0, 1.0);
}

// ---------------------------------------------------------------- LAYER 2 ---
vec3 lutFetch(ivec3 p, int N) {
    p = clamp(p, ivec3(0), ivec3(N - 1));
    return texelFetch(uLutTex, p, 0).rgb;
}

vec3 sampleLutTetrahedral(vec3 c, int N) {
    vec3  x  = clamp(c, 0.0, 1.0) * float(N - 1);
    ivec3 i0 = ivec3(floor(min(x, vec3(float(N - 2)))));
    vec3  f  = x - vec3(i0);
    ivec3 i1 = i0 + 1;

    vec3 c000 = lutFetch(i0, N);
    vec3 c111 = lutFetch(i1, N);
    vec3 res;
    if (f.r >= f.g && f.g >= f.b) {
        vec3 c100 = lutFetch(ivec3(i1.x, i0.y, i0.z), N);
        vec3 c110 = lutFetch(ivec3(i1.x, i1.y, i0.z), N);
        res = (1.0-f.r)*c000 + (f.r-f.g)*c100 + (f.g-f.b)*c110 + f.b*c111;
    } else if (f.r >= f.b && f.b >= f.g) {
        vec3 c100 = lutFetch(ivec3(i1.x, i0.y, i0.z), N);
        vec3 c101 = lutFetch(ivec3(i1.x, i0.y, i1.z), N);
        res = (1.0-f.r)*c000 + (f.r-f.b)*c100 + (f.b-f.g)*c101 + f.g*c111;
    } else if (f.b >= f.r && f.r >= f.g) {
        vec3 c001 = lutFetch(ivec3(i0.x, i0.y, i1.z), N);
        vec3 c101 = lutFetch(ivec3(i1.x, i0.y, i1.z), N);
        res = (1.0-f.b)*c000 + (f.b-f.r)*c001 + (f.r-f.g)*c101 + f.g*c111;
    } else if (f.g >= f.r && f.r >= f.b) {
        vec3 c010 = lutFetch(ivec3(i0.x, i1.y, i0.z), N);
        vec3 c110 = lutFetch(ivec3(i1.x, i1.y, i0.z), N);
        res = (1.0-f.g)*c000 + (f.g-f.r)*c010 + (f.r-f.b)*c110 + f.b*c111;
    } else if (f.g >= f.b && f.b >= f.r) {
        vec3 c010 = lutFetch(ivec3(i0.x, i1.y, i0.z), N);
        vec3 c011 = lutFetch(ivec3(i0.x, i1.y, i1.z), N);
        res = (1.0-f.g)*c000 + (f.g-f.b)*c010 + (f.b-f.r)*c011 + f.r*c111;
    } else {
        vec3 c001 = lutFetch(ivec3(i0.x, i0.y, i1.z), N);
        vec3 c011 = lutFetch(ivec3(i0.x, i1.y, i1.z), N);
        res = (1.0-f.b)*c000 + (f.b-f.g)*c001 + (f.g-f.r)*c011 + f.r*c111;
    }
    return res;
}

vec3 applyLayer2(vec3 src) {
    if (uL2On < 0.5 || uLutIntensity <= 0.001 || uLutSize < 2.0) return src;
    float inten = clamp(uLutIntensity, 0.0, 1.0);
    // LUT nuoc sau thuong keo ca tia nang thanh mang cyan bet. Giam dan cuong
    // do LUT o vung luma cao de giu lai tia nang, muc do do nguoi dung chon.
    inten *= 1.0 - uLumaProtect * smoothstep(0.75, 1.0, luma709(src));
    if (inten <= 0.001) return src;
    return mix(src, sampleLutTetrahedral(src, int(uLutSize)), inten);
}

/*
 * Zebras — canh bao phoi sang. Man hinh dien thoai ngoai nang khong the tin
 * duoc, nen danh dau thang len khung hinh: soc DO = da chay sang (mat chi
 * tiet), soc XANH = da bet den. Soc chay cham theo uTime de phan biet voi hoa
 * tiet co that trong canh.
 */
vec3 zebras(vec3 c, vec2 uv) {
    if (uZebra < 0.5) return c;
    float y = luma709(c);
    float s = sin((uv.x + uv.y) * 260.0 - uTime * 2.5);
    if (s <= 0.0) return c;
    if (y > 0.98) return vec3(1.0, 0.12, 0.08);
    if (y < 0.02) return vec3(0.15, 0.42, 1.0);
    return c;
}

// ---------------------------------------------------------------- LAYER 3 ---
vec3 rgb2hsv(vec3 c) {
    vec4 K = vec4(0.0, -1.0/3.0, 2.0/3.0, -1.0);
    vec4 p = mix(vec4(c.bg, K.wz), vec4(c.gb, K.xy), step(c.b, c.g));
    vec4 q = mix(vec4(p.xyw, c.r), vec4(c.r, p.yzx), step(p.x, c.r));
    float d = q.x - min(q.w, q.y);
    float e = 1.0e-10;
    return vec3(abs(q.z + (q.w - q.y) / (6.0 * d + e)), d / (q.x + e), q.x);
}
vec3 hsv2rgb(vec3 c) {
    vec4 K = vec4(1.0, 2.0/3.0, 1.0/3.0, 3.0);
    vec3 p = abs(fract(c.xxx + K.xyz) * 6.0 - K.www);
    return c.z * mix(K.xxx, clamp(p - K.xxx, 0.0, 1.0), c.y);
}

float bandWeight(float hueDeg, float center) {
    float d = abs(hueDeg - center);
    d = min(d, 360.0 - d);
    float t = d / HSL_WIDTH;
    return exp(-t * t);
}

float skinLockWeight(vec3 hsvIn) {
    float hueDeg = hsvIn.x * 360.0;
    float d = abs(hueDeg - uSkinMask.x);
    d = min(d, 360.0 - d);
    float w = 1.0 - smoothstep(uSkinMask.y, uSkinMask.y + uSkinMask.z, d);
    w *= smoothstep(uSkinMask2.z, uSkinMask2.z + 0.10, hsvIn.y);
    w *= smoothstep(uSkinMask2.w, uSkinMask2.w + 0.08, hsvIn.z);
    return clamp(w, 0.0, 1.0);
}

void main() {
    vec3 src = texture(uTexSampler, vTexSamplingCoord).rgb;

    // ---- Ben TRAI thanh truot: anh goc (chi chuyen khong gian mau) ----
    if (uWipeX > 0.0001 && vTexSamplingCoord.x < uWipeX) {
        outColor = vec4(clamp(linearToRec709(dlogMToLinear(src)), 0.0, 1.0), 1.0);
        return;
    }

    vec3 c = applyLayer1(src);
    c = applyLayer2(c);

    // ---- Layer 3 ----
    vec3 cIn = c;
    if (uL3On < 0.5) {
        outColor = vec4(zebras(clamp(c, 0.0, 1.0), vTexSamplingCoord), 1.0);
        return;
    }

    vec3 hsvIn = rgb2hsv(cIn);
    float lockW = (uSkinMask2.x > 0.5) ? skinLockWeight(hsvIn) * uSkinMask.w : 0.0;
    if (uSkinMask2.y > 0.5) {                 // che do xem mask (debug)
        outColor = vec4(vec3(lockW), 1.0);
        return;
    }

    vec3 hsv = hsvIn;
    float hueDeg = hsv.x * 360.0;
    bool skinBand = (hueDeg >= 15.0 && hueDeg <= 45.0);

    float hueShift = 0.0;
    float satMul = 1.0;
    float lumaAdd = 0.0;

    float w;
    w = bandWeight(hueDeg,   0.0); hueShift += w * uHsl0.x; satMul *= 1.0 + w * uHsl0.y; lumaAdd += w * uHsl0.z * 0.30;
    w = bandWeight(hueDeg,  30.0); hueShift += w * uHsl1.x; satMul *= 1.0 + w * uHsl1.y; lumaAdd += w * uHsl1.z * 0.30;
    w = bandWeight(hueDeg,  60.0); hueShift += w * uHsl2.x; satMul *= 1.0 + w * uHsl2.y; lumaAdd += w * uHsl2.z * 0.30;
    w = bandWeight(hueDeg, 120.0); hueShift += w * uHsl3.x; satMul *= 1.0 + w * uHsl3.y; lumaAdd += w * uHsl3.z * 0.30;
    w = bandWeight(hueDeg, 180.0); hueShift += w * uHsl4.x; satMul *= 1.0 + w * uHsl4.y; lumaAdd += w * uHsl4.z * 0.30;
    w = bandWeight(hueDeg, 240.0); hueShift += w * uHsl5.x; satMul *= 1.0 + w * uHsl5.y; lumaAdd += w * uHsl5.z * 0.30;
    w = bandWeight(hueDeg, 300.0); hueShift += w * uHsl6.x; satMul *= 1.0 + w * uHsl6.y; lumaAdd += w * uHsl6.z * 0.30;

    if (uSkinProtect > 0.5 && skinBand) {
        hueShift = 0.0;
        satMul = clamp(satMul, 0.95, 1.08);
    }
    hsv.x = fract(hsv.x + hueShift / 360.0 + 1.0);
    hsv.y = clamp(hsv.y * satMul, 0.0, 1.0);
    hsv.z = clamp(hsv.z * (1.0 + lumaAdd), 0.0, 1.0);
    c = hsv2rgb(hsv);

    float Y = luma709(c);
    c = mix(vec3(Y), c, 1.0 + uGlobalSat);
    c += uShadowTint * pow(1.0 - Y, 2.0);

    c = mix(c, cIn, lockW);

    c = zebras(clamp(c, 0.0, 1.0), vTexSamplingCoord);
    outColor = vec4(c, 1.0);
}
