// ============================================================================
//  CUSTOM SLIDER — thanh truot ve tay bang Canvas
//  Vi sao khong dung Slider cua Material3: mockup yeu cau MAU TRACK theo cong
//  cu (Temperature cam, Tint magenta, Red Recovery gradient do, Anti-Green xanh
//  la), track mo phia sau va nhan/gia tri nam tren cung mot dong. Ghi de mau
//  cua Material se phai chong len nhieu lop; ve thang bang Canvas gon hon va
//  kiem soat duoc tung pixel.
//
//  Track ve tu MOC 0 (khong phai tu bien trai) voi cac slider hai chieu, de
//  nhin la biet dang keo am hay duong.
// ============================================================================
package com.freedive.colorapp.ui.compose

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material3.Text
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * @param value        gia tri hien tai
 * @param range        (min, max)
 * @param trackColor   mau doan da keo
 * @param trackColorEnd neu khac null -> track la gradient (Red Recovery)
 * @param bipolar      true = ve tu moc 0 ra hai phia
 * @param format       cach hien so ben phai (vd "+60", "+0.00 EV")
 */
@Composable
fun FdcSlider(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onValueChange: (Float) -> Unit,
    modifier: Modifier = Modifier,
    trackColor: Color = Fdc.Neutral,
    trackColorEnd: Color? = null,
    bipolar: Boolean = true,
    format: (Float) -> String = { fmtSigned(it) },
    enabled: Boolean = true,
) {
    val min = range.start
    val max = range.endInclusive
    var widthPx by remember { mutableFloatStateOf(1f) }
    val density = LocalDensity.current

    fun fractionOf(v: Float) = ((v - min) / (max - min)).coerceIn(0f, 1f)
    fun valueAt(x: Float) = (min + (max - min) * (x / widthPx).coerceIn(0f, 1f))

    Column(modifier = modifier.fillMaxWidth().padding(vertical = 6.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Text(
                text = label,
                color = if (enabled) Fdc.Text else Fdc.TextMuted,
                fontSize = 13.sp,
                maxLines = 1,
                modifier = Modifier.weight(1f)
            )
            // Mockup: gia tri bang 0 hien mau xam, khac 0 moi an mau track
            val valueColor = when {
                !enabled -> Fdc.TextMuted
                kotlin.math.abs(value) < 0.0005f -> Fdc.TextMuted
                else -> trackColor
            }
            Text(
                text = format(value),
                color = valueColor,
                fontSize = 13.sp,
                fontFamily = Fdc.Mono,
                fontWeight = FontWeight.Bold,
            )
        }

        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(28.dp)
                .pointerInput(enabled, min, max) {
                    if (!enabled) return@pointerInput
                    detectTapGestures { pos -> onValueChange(valueAt(pos.x)) }
                }
                .pointerInput(enabled, min, max) {
                    if (!enabled) return@pointerInput
                    detectDragGestures { change, _ ->
                        change.consume()
                        onValueChange(valueAt(change.position.x))
                    }
                }
        ) {
            widthPx = size.width
            val cy = size.height / 2f
            val trackH = with(density) { 3.dp.toPx() }
            val knobR = with(density) { 8.dp.toPx() }

            // Track nen
            drawLine(
                color = Fdc.Stroke,
                start = Offset(0f, cy),
                end = Offset(size.width, cy),
                strokeWidth = trackH,
                cap = StrokeCap.Round,
            )

            val f = fractionOf(value)
            val knobX = f * size.width
            // Diem goc de ve doan da keo: moc 0 neu bipolar va 0 nam trong khoang
            val zeroX = if (bipolar && min < 0f && max > 0f) fractionOf(0f) * size.width else 0f

            val brush = if (trackColorEnd != null)
                Brush.horizontalGradient(listOf(trackColor, trackColorEnd))
            else Brush.horizontalGradient(listOf(trackColor, trackColor))

            val left = minOf(zeroX, knobX)
            val right = maxOf(zeroX, knobX)
            if (right - left > 0.5f) {
                drawRoundRect(
                    brush = brush,
                    topLeft = Offset(left, cy - trackH / 2f),
                    size = Size(right - left, trackH),
                )
            }

            // Vach moc 0
            if (bipolar && min < 0f && max > 0f) {
                drawLine(
                    color = Fdc.TextMuted,
                    start = Offset(zeroX, cy - knobR * 0.7f),
                    end = Offset(zeroX, cy + knobR * 0.7f),
                    strokeWidth = with(density) { 1.dp.toPx() },
                )
            }

            // Nut keo
            drawCircle(color = Fdc.Bg, radius = knobR, center = Offset(knobX, cy))
            drawCircle(
                color = if (enabled) trackColor else Fdc.TextMuted,
                radius = knobR - with(density) { 2.dp.toPx() },
                center = Offset(knobX, cy),
            )
        }
    }
}

// ---------------------------------------------------------------------------
/** "+60", "-25", "0" — kieu hien so cua mockup (thang do -100..100) */
fun fmtSigned(v: Float): String {
    val n = (v * 100f).roundToInt()
    return if (n > 0) "+$n" else "$n"
}

/** "+0.00 EV" cho phoi sang */
fun fmtEv(v: Float): String =
    (if (v >= 0) "+" else "-") + "%.2f EV".format(abs(v))

/** "0.35" cho cac tham so 0..1 khong quy ve thang 100 */
fun fmtPlain(v: Float): String = "%.2f".format(v)

/** "25°" cho goc hue */
fun fmtDeg(v: Float): String = "${v.roundToInt()}°"
