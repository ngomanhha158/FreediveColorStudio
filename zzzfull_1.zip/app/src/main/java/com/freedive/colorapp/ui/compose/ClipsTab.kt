// ============================================================================
//  TAB CLIPS — danh sach clip + thao tac hang loat
//  Moi dong: anh dai dien, ten file, thoi luong. Mockup con co nhan dia diem
//  ("Phu Quoc · drop-off") nhung du lieu do khong nam trong file video, nen o
//  day hien thu muc nguon thay vi bia ra mot dia danh khong co that.
//  Hang duoi: Copy / Paste / Paste All / Reset — grade mot clip roi ap cho ca
//  buoi lan.
// ============================================================================
package com.freedive.colorapp.ui.compose

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.freedive.colorapp.ui.L

@Composable
fun ClipsTab(ui: FdcUiState, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = Fdc.PagePad, end = Fdc.PagePad, top = 12.dp, bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = L.t("CLIP (${ui.clips.size})", "CLIPS (${ui.clips.size})"),
                color = Fdc.TextMuted, fontSize = 10.sp,
                fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp,
                modifier = Modifier.weight(1f),
            )
            SmallButton(L.t("Thêm video", "Add video")) { ui.onPickVideo() }
        }

        if (ui.clips.isEmpty()) {
            Box(
                Modifier.fillMaxWidth().height(120.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    L.t("Chưa có clip nào — bấm “Thêm video”",
                        "No clips yet — tap “Add video”"),
                    color = Fdc.TextMuted, fontSize = 12.sp,
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f, fill = false),
                contentPadding = PaddingValues(horizontal = Fdc.PagePad, vertical = 4.dp),
            ) {
                items(ui.clips) { clip ->
                    ClipRow(clip, selected = clip.uri == ui.currentUri) {
                        ui.onSelectClip(clip.uri)
                    }
                }
            }
        }

        // ---- Thao tac hang loat ----
        Text(
            text = L.t("THAO TÁC HÀNG LOẠT", "BATCH ACTIONS"),
            color = Fdc.TextMuted, fontSize = 10.sp,
            fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp,
            modifier = Modifier.padding(start = Fdc.PagePad, top = 14.dp, bottom = 6.dp),
        )
        Row(
            modifier = Modifier.fillMaxWidth().padding(start = Fdc.PagePad, end = Fdc.PagePad, bottom = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(Fdc.Gap),
        ) {
            SmallButton("Copy") { ui.onCopyGrade() }
            SmallButton("Paste") { ui.onPasteGrade() }
            SmallButton("Paste All") { ui.onPasteAll() }
            SmallButton("Reset") { ui.onResetGrade() }
        }
        // Xuat ca buoi lan mot lan — nut tren thanh dau chi xuat clip dang mo
        Row(
            modifier = Modifier.fillMaxWidth()
                .padding(start = Fdc.PagePad, end = Fdc.PagePad, bottom = 16.dp),
        ) {
            SmallButton(L.t("⇪  Xuất tất cả clip", "⇪  Export all clips")) { ui.onExportAll() }
        }
    }
}

@Composable
private fun ClipRow(clip: ClipItem, selected: Boolean, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .clip(RoundedCornerShape(Fdc.Radius))
            .background(if (selected) Fdc.CardHi else Fdc.Card)
            .clickable { onClick() }
            .padding(8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            modifier = Modifier
                .width(72.dp)
                .height(44.dp)
                .clip(RoundedCornerShape(6.dp))
                .background(Color.Black),
            contentAlignment = Alignment.Center,
        ) {
            val bmp = clip.thumbnail
            if (bmp != null) {
                Image(
                    bitmap = bmp.asImageBitmap(),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.size(width = 72.dp, height = 44.dp),
                )
            }
        }
        Column(Modifier.weight(1f).padding(start = 10.dp)) {
            Text(
                clip.name,
                color = if (selected) Fdc.Text else Fdc.TextDim,
                fontSize = 13.sp,
                fontFamily = Fdc.Mono,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
            )
            Text(
                text = clip.location ?: "D-Log M",
                color = Fdc.TextMuted,
                fontSize = 10.sp,
                maxLines = 1,
            )
        }
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(5.dp))
                .background(Color.Black.copy(alpha = 0.45f))
                .padding(horizontal = 6.dp, vertical = 3.dp),
        ) {
            Text(
                clockMs(clip.durationMs),
                color = Fdc.TextDim, fontSize = 10.sp, fontFamily = Fdc.Mono,
            )
        }
    }
}

private fun clockMs(ms: Long): String {
    val t = ms.coerceAtLeast(0L)
    val m = t / 60000L
    val s = (t % 60000L) / 1000L
    return "%d:%02d".format(m, s)
}
