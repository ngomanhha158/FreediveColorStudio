// ============================================================================
//  SPLIT WIPE PLAYER — khung phat + thanh truot so sanh Before/After
//
//  Cach hoat dong: KHONG ve hai lop video chong nhau (ton gap doi GPU). Thay
//  vao do vi tri thanh truot duoc day xuong shader qua GradeBus.wipeX; ben
//  TRAI moc do shader chi lam CST (D-Log M -> Rec.709) roi thoi, ben PHAI chay
//  du ba layer. Mot lan ve, khong ton them gi.
//
//  Thanh truot duoc gioi han trong DUNG khung anh that: video duoc scale "fit"
//  nen co vien den; neu tha thanh truot chay het be ngang View thi vach chia va
//  ranh gioi trong shader se lech nhau.
// ============================================================================
package com.freedive.colorapp.ui.compose

import android.view.SurfaceView
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.common.util.UnstableApi
import com.freedive.colorapp.player.GradeBus
import com.freedive.colorapp.player.GradePlayer
import com.freedive.colorapp.ui.L

@UnstableApi
@Composable
fun SplitWipePlayer(
    gradePlayer: GradePlayer,
    presetName: String,
    modifier: Modifier = Modifier,
    showScopes: Boolean = true,
) {
    val player = gradePlayer.player
    var videoW by remember { mutableFloatStateOf(0f) }
    var videoH by remember { mutableFloatStateOf(0f) }
    // 0f = khong so sanh (toan bo da grade); keo ra giua = 0.5f
    var wipe by remember { mutableFloatStateOf(0f) }

    DisposableEffect(player) {
        val l = object : Player.Listener {
            override fun onVideoSizeChanged(size: VideoSize) {
                videoW = size.width.toFloat()
                videoH = size.height.toFloat()
            }
        }
        player.addListener(l)
        onDispose { player.removeListener(l) }
    }

    BoxWithConstraints(modifier = modifier.background(Color.Black)) {
        val density = LocalDensity.current
        val boxW = with(density) { maxWidth.toPx() }
        val boxH = with(density) { maxHeight.toPx() }

        // Hinh chu nhat that su cua video ben trong khung (scale "fit")
        val videoRatio = if (videoW > 0f && videoH > 0f) videoW / videoH else 16f / 9f
        val boxRatio = if (boxH > 0f) boxW / boxH else 16f / 9f
        val dispW = if (videoRatio > boxRatio) boxW else boxH * videoRatio
        val dispLeft = (boxW - dispW) / 2f

        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx -> SurfaceView(ctx).also { player.setVideoSurfaceView(it) } },
            onRelease = { player.clearVideoSurface() },
        )

        // ---- Thanh truot so sanh ----
        Box(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(dispW, dispLeft) {
                    detectDragGestures(
                        onDragStart = { pos ->
                            if (dispW > 0f) {
                                wipe = ((pos.x - dispLeft) / dispW).coerceIn(0f, 1f)
                                GradeBus.setWipe(wipe)
                            }
                        }
                    ) { change, _ ->
                        change.consume()
                        if (dispW > 0f) {
                            wipe = ((change.position.x - dispLeft) / dispW).coerceIn(0f, 1f)
                            GradeBus.setWipe(wipe)
                        }
                    }
                }
        )

        if (wipe > 0.001f) {
            val xPx = dispLeft + wipe * dispW
            val xDp = with(density) { xPx.toDp() }
            // Vach chia
            Box(
                modifier = Modifier
                    .offset(x = xDp - 1.dp)
                    .width(2.dp)
                    .fillMaxHeight()
                    .background(Color.White.copy(alpha = 0.9f))
            )
            // Tay cam () o giua
            Box(
                modifier = Modifier
                    .offset(x = xDp - 18.dp)
                    .align(Alignment.CenterStart)
                    .size(36.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .background(Color.White.copy(alpha = 0.92f)),
                contentAlignment = Alignment.Center,
            ) {
                Text("( )", color = Fdc.Bg, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }
            Badge(
                text = "BEFORE",
                bg = Color.Black.copy(alpha = 0.6f),
                fg = Fdc.TextDim,
                modifier = Modifier.align(Alignment.TopStart).padding(10.dp),
            )
        }

        Badge(
            text = if (wipe > 0.001f) "AFTER · ${presetName.uppercase()}" else presetName.uppercase(),
            bg = Fdc.AccentDeep.copy(alpha = 0.85f),
            fg = Fdc.Text,
            modifier = Modifier.align(Alignment.TopEnd).padding(10.dp),
        )

        Text(
            text = L.t("Kéo ngang khung hình để so sánh", "Drag across the frame to compare"),
            color = Fdc.TextMuted,
            fontSize = 10.sp,
            modifier = Modifier.align(Alignment.BottomStart).padding(10.dp),
        )

        if (showScopes) {
            FloatingScopes(modifier = Modifier.align(Alignment.TopEnd))
        }
    }
}

@Composable
private fun Badge(text: String, bg: Color, fg: Color, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(bg)
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Text(text, color = fg, fontSize = 10.sp, fontWeight = FontWeight.Bold)
    }
}

/**
 * The Scopes noi, keo tha duoc.
 * Trang thai hien tai: khung da san sang nhung SO LIEU chua co — Vectorscope /
 * Waveform cu chay bang compute shader Vulkan, chua port sang GL ES. De trong
 * con hon ve mot vong tron gia lam nguoi dung tuong dang doc duoc mau.
 */
@Composable
private fun FloatingScopes(modifier: Modifier = Modifier) {
    var dx by remember { mutableFloatStateOf(0f) }
    var dy by remember { mutableFloatStateOf(0f) }
    val density = LocalDensity.current

    Column(
        modifier = modifier
            .offset(x = with(density) { dx.toDp() }, y = with(density) { dy.toDp() })
            .padding(top = 44.dp, end = 10.dp)
            .size(width = 120.dp, height = 96.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(Color.Black.copy(alpha = 0.55f))
            .padding(8.dp)
            .pointerInput(Unit) {
                detectDragGestures { change, drag ->
                    change.consume()
                    dx += drag.x
                    dy += drag.y
                }
            },
    ) {
        Text("VECTORSCOPE", color = Fdc.TextDim, fontSize = 8.sp, fontWeight = FontWeight.Bold)
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text(
                L.t("Chưa có dữ liệu\n(chờ port compute shader)",
                    "No data yet\n(compute shader pending)"),
                color = Fdc.TextMuted,
                fontSize = 8.sp,
            )
        }
    }
}
