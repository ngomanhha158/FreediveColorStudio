// ============================================================================
//  TRANSFORMER EXPORTER — xuat file bang Media3 Transformer
//
//  Diem quan trong nhat: xuat dung CHINH hai effect ma preview dang chay
//  (GradeGlEffect + ClarityGlEffect). Truoc day preview chay Vulkan con export
//  chay mot duong render rieng — hai duong khac nhau thi mau xuat ra khong bao
//  gio chac chan khop voi mau dang nhin. Nay cung mot shader, cung mot tham so.
//
//  Moi clip mang theo BAN CHUP tham so cua rieng no (paramsFor / lutFor), nen
//  xuat hang loat khong bi dinh grade cua clip dang mo tren man hinh.
//
//  Xuat TUAN TU tung clip: encoder phan cung chi co vai instance, chay song
//  song se tranh nhau va hong giua chung.
//
//  GIOI HAN DA BIET — dau ra 8-bit:
//  File D-Log M cua DJI gan the bt709 (SDR), nen Media3 dung context GL o che
//  do SDR (RGBA8888). Toan chuoi hieu ung vi the la 8-bit, khac ban Vulkan cu
//  (fp16). Muon 10-bit that su thi phai cho frame processor chay che do HDR —
//  viec rieng, chua lam o day.
// ============================================================================
package com.freedive.colorapp.player

import android.content.Context
import android.net.Uri
import android.os.Environment
import android.os.Handler
import android.os.Looper
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.util.UnstableApi
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import com.freedive.colorapp.export.ExportCodec
import com.freedive.colorapp.export.ExportConfig
import java.io.File

/** Mot clip trong hang doi xuat, kem ban chup grade cua rieng no */
data class ExportJob(
    val uri: Uri,
    val displayName: String,
    val params: FloatArray,
    val lutPath: String,
) {
    override fun equals(other: Any?): Boolean =
        other is ExportJob && other.uri == uri && other.params.contentEquals(params)
    override fun hashCode(): Int = 31 * uri.hashCode() + params.contentHashCode()
}

@UnstableApi
class TransformerExporter(private val context: Context) {

    /** (thu tu clip 1-based, tong so, phan tram clip hien tai) */
    var onProgress: ((Int, Int, Int) -> Unit)? = null
    var onFinished: ((List<File>) -> Unit)? = null
    var onError: ((String) -> Unit)? = null

    var running = false
        private set

    private val main = Handler(Looper.getMainLooper())
    private val done = mutableListOf<File>()
    private var queue: List<ExportJob> = emptyList()
    private var index = 0
    private var config = ExportConfig()
    private var transformer: Transformer? = null

    private val progressHolder = ProgressHolder()
    private val progressTick = object : Runnable {
        override fun run() {
            val t = transformer ?: return
            val state = runCatching { t.getProgress(progressHolder) }.getOrNull()
            if (state != null && state != Transformer.PROGRESS_STATE_NOT_STARTED) {
                onProgress?.invoke(index + 1, queue.size, progressHolder.progress)
            }
            if (running) main.postDelayed(this, 250)
        }
    }

    // ------------------------------------------------------------------------
    fun start(jobs: List<ExportJob>, cfg: ExportConfig) {
        if (running) return
        if (jobs.isEmpty()) { onError?.invoke("Khong co clip nao de xuat"); return }
        queue = jobs
        config = cfg
        index = 0
        done.clear()
        running = true
        main.post(progressTick)
        exportCurrent()
    }

    fun cancel() {
        running = false
        runCatching { transformer?.cancel() }
        transformer = null
        main.removeCallbacks(progressTick)
    }

    // ------------------------------------------------------------------------
    private fun exportCurrent() {
        if (!running) return
        if (index >= queue.size) {
            running = false
            main.removeCallbacks(progressTick)
            onFinished?.invoke(done.toList())
            return
        }
        val job = queue[index]
        val out = outputFile(job.displayName)

        // Tham so CO DINH cho clip nay — khong doc GradeBus
        val params = job.params
        val lut = job.lutPath
        val videoEffects: List<Effect> = listOf(
            GradeGlEffect(
                params = { params },
                lutPath = { lut },
                wipe = { 0f },          // xuat file thi khong co thanh so sanh
                zebra = { false },      // zebras la cong cu soi, khong duoc ghi vao file
            ),
            ClarityGlEffect(params = { params }),
        )

        val item = EditedMediaItem.Builder(MediaItem.fromUri(job.uri))
            .setRemoveAudio(config.muteAudio)
            .setEffects(Effects(emptyList<AudioProcessor>(), videoEffects))
            .build()

        val t = Transformer.Builder(context)
            .setVideoMimeType(
                if (config.codec == ExportCodec.AVC_8BIT) MimeTypes.VIDEO_H264
                else MimeTypes.VIDEO_H265
            )
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, result: ExportResult) {
                    done += out
                    index++
                    main.post { exportCurrent() }
                }

                override fun onError(
                    composition: Composition,
                    result: ExportResult,
                    exception: ExportException,
                ) {
                    running = false
                    main.removeCallbacks(progressTick)
                    val why = exception.cause?.message ?: exception.message ?: "khong ro"
                    onError?.invoke("${job.displayName}: $why")
                }
            })
            .build()

        transformer = t
        runCatching { t.start(item, out.absolutePath) }
            .onFailure {
                running = false
                main.removeCallbacks(progressTick)
                onError?.invoke("${job.displayName}: ${it.message}")
            }
    }

    /** Thu muc Movies rieng cua app — khong can quyen ghi bo nho ngoai */
    private fun outputFile(displayName: String): File {
        val dir = context.getExternalFilesDir(Environment.DIRECTORY_MOVIES)
            ?: context.filesDir
        dir.mkdirs()
        val base = displayName.substringBeforeLast('.')
            .replace(Regex("[^A-Za-z0-9_\\-]"), "_")
            .ifEmpty { "clip" }
        var f = File(dir, "${base}_graded.mp4")
        var n = 2
        while (f.exists()) { f = File(dir, "${base}_graded($n).mp4"); n++ }
        return f
    }
}
