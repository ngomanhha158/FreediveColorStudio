// ============================================================================
//  FDC THEME — bang mau / kieu chu cho giao dien Compose
//  Nen navy sau, chip bo tron, so lieu font mono. Mau track cua slider mang y
//  nghia cong cu (Temperature cam, Tint magenta, Red Recovery do, Anti-Green
//  xanh la) — nguoi grade nhan ra thanh nao lam gi ma khong can doc nhan.
// ============================================================================
package com.freedive.colorapp.ui.compose

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp

object Fdc {
    // ---- Nen ----
    val Bg          = Color(0xFF0A101C)   // nen sau nhat
    val Panel       = Color(0xFF111A28)   // panel duoi
    val Card        = Color(0xFF16202F)   // the / chip nghi
    val CardHi      = Color(0xFF1E2C40)   // the duoc chon
    val Stroke      = Color(0x22FFFFFF)
    val StrokeOn    = Color(0xFF2FA3E0)

    // ---- Chu ----
    val Text        = Color(0xFFE9F1F9)
    val TextDim     = Color(0xFF93A6BC)
    val TextMuted   = Color(0xFF5F7186)

    // ---- Nhan / hanh dong ----
    val Accent      = Color(0xFF2FA3E0)   // xanh nuoc — mau chu dao
    val AccentDeep  = Color(0xFF13567D)

    // ---- Mau track theo cong cu (theo mockup) ----
    val Temperature = Color(0xFFFF9F2E)   // cam
    val Tint        = Color(0xFFFF5CC8)   // magenta
    val RedRecovery = Color(0xFFFF3B30)   // do
    val RedLight    = Color(0xFFFF8A80)   // do nhat — dau kia cua gradient
    val AntiGreen   = Color(0xFF2BE07A)   // xanh la
    val Neutral     = Color(0xFF4FC3F7)   // xanh nhat — cac slider con lai
    val Warn        = Color(0xFFE0873A)

    val Mono = FontFamily.Monospace

    // ---- Kich thuoc dung chung ----
    val Radius      = 12.dp
    val RadiusChip  = 10.dp
    val Gap         = 8.dp
    val PagePad     = 12.dp
}
