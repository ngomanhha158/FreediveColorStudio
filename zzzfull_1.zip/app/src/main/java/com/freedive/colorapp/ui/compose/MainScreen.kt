// ============================================================================
//  MAIN SCREEN — bo cuc tong
//    Thanh tren (logo · ten app · ten file · nut Xuat)
//    Khung phat (so sanh Before/After + Scopes noi + Zebras)
//    Dai preset — nam NGOAI tab, hien o ca Adjust lan Clips
//    Noi dung tab · Thanh dieu huong duoi
//
//  CHE DO XEM (Review mode): keo tay cam o dinh bang cong cu xuong -> bang cong
//  cu thu lai, khung hinh chiem het chieu cao con lai. Cham vao khung hinh de
//  quay ve che do chinh.
//
//  Noi thang: voi canh quay 16:9 tren man hinh doc, khung hinh KHONG to them
//  duoc — anh da rong bang be ngang man hinh roi, ke tren duoi chi la vien den.
//  Cai duoc thuc su la mat khong con bi cac mang mau cua giao dien lam nhieu
//  khi danh gia mau (day la hien tuong that trong nghe grade). Muon anh to hon
//  thi phai xoay ngang may — viec do chua lam.
// ============================================================================
package com.freedive.colorapp.ui.compose

import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.util.UnstableApi
import com.freedive.colorapp.player.GradeBus
import com.freedive.colorapp.player.GradePlayer
import com.freedive.colorapp.ui.L

@UnstableApi
@Composable
fun MainScreen(player: GradePlayer, ui: FdcUiState) {
    var tab by remember { mutableIntStateOf(0) }
    var showScopes by remember { mutableStateOf(true) }
    var zebra by remember { mutableStateOf(false) }
    var reviewMode by remember { mutableStateOf(false) }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Fdc.Accent,
            background = Fdc.Bg,
            surface = Fdc.Panel,
            onBackground = Fdc.Text,
            onSurface = Fdc.Text,
        )
    ) {
        // targetSdk 36 ep edge-to-edge: phai tru inset, khong thi thanh tren
        // chui duoi thanh trang thai.
        BoxWithConstraints(
            Modifier
                .fillMaxSize()
                .background(Fdc.Bg)
                .windowInsetsPadding(WindowInsets.statusBars)
        ) {
            val editH = maxWidth * 9f / 16f          // khung 16:9 khi dang chinh
            val fullH = maxHeight                    // chiem het khi dang xem
            val playerH by animateDpAsState(
                targetValue = if (reviewMode) fullH else editH,
                animationSpec = tween(280),
                label = "playerHeight",
            )

            Column(Modifier.fillMaxSize()) {

                if (!reviewMode) {
                    TopBar(
                        fileName = ui.currentName.ifEmpty { L.t("Chưa chọn clip", "No clip") },
                        onExport = ui.onExport,
                    )
                }

                // ---- Khung phat ----
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(playerH)
                        .clickable(enabled = reviewMode) { reviewMode = false }
                ) {
                    SplitWipePlayer(
                        gradePlayer = player,
                        presetName = if (ui.activePreset >= 0) PRESET_NAMES[ui.activePreset]
                                     else L.t("Gốc", "Original"),
                        showScopes = showScopes,
                        modifier = Modifier.fillMaxSize(),
                    )

                    // Hai nut cong cu soi, goc trai-duoi
                    Row(
                        modifier = Modifier.align(Alignment.BottomStart).padding(10.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        RoundToolButton(
                            active = showScopes,
                            onClick = { showScopes = !showScopes },
                        ) { HslIcon(if (showScopes) Fdc.Accent else Fdc.TextMuted) }

                        RoundToolButton(
                            active = zebra,
                            onClick = { zebra = !zebra; GradeBus.setZebra(zebra) },
                        ) { ZebraIcon(if (zebra) Fdc.Warn else Fdc.TextMuted) }
                    }

                    if (reviewMode) {
                        Text(
                            text = L.t("Chạm để hiện lại bảng công cụ",
                                       "Tap to bring the tools back"),
                            color = Fdc.TextMuted,
                            fontSize = 11.sp,
                            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 24.dp),
                        )
                    }
                }

                if (!reviewMode) {
                    // ---- Tay cam keo xuong de xem toan man hinh ----
                    DragHandle { reviewMode = true }

                    ui.status?.let { msg ->
                        Text(
                            text = msg,
                            color = Fdc.Warn,
                            fontSize = 11.sp,
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color(0x22E0873A))
                                .padding(horizontal = Fdc.PagePad, vertical = 6.dp),
                        )
                    }

                    ui.exportProgress?.let { msg ->
                        Text(
                            text = msg,
                            color = Fdc.Accent,
                            fontSize = 11.sp,
                            fontFamily = Fdc.Mono,
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color(0x222FA3E0))
                                .padding(horizontal = Fdc.PagePad, vertical = 6.dp),
                        )
                    }

                    PresetStrip(ui)

                    Box(Modifier.weight(1f).fillMaxWidth()) {
                        when (tab) {
                            0 -> AdjustTab(ui)
                            1 -> HslTab(ui)
                            2 -> DepthTab(ui)
                            else -> ClipsTab(ui)
                        }
                    }

                    Box(Modifier.windowInsetsPadding(WindowInsets.navigationBars)) {
                        BottomNav(selected = tab, onSelect = { tab = it })
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------
/** Tay cam hinh vien thuoc — keo xuong de an bang cong cu */
@Composable
private fun DragHandle(onCollapse: () -> Unit) {
    var acc by remember { mutableFloatStateOf(0f) }
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(22.dp)
            .background(Fdc.Bg)
            .pointerInput(Unit) {
                detectVerticalDragGestures(
                    onDragStart = { acc = 0f },
                    onDragEnd = { acc = 0f },
                ) { change, dy ->
                    change.consume()
                    acc += dy
                    if (acc > 70f) { onCollapse(); acc = 0f }
                }
            }
            .clickable { onCollapse() },
        contentAlignment = Alignment.Center,
    ) {
        Box(
            Modifier
                .width(40.dp)
                .height(4.dp)
                .clip(RoundedCornerShape(2.dp))
                .background(Fdc.TextMuted)
        )
    }
}

@Composable
private fun RoundToolButton(
    active: Boolean,
    onClick: () -> Unit,
    icon: @Composable () -> Unit,
) {
    Box(
        modifier = Modifier
            .size(32.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(Color.Black.copy(alpha = if (active) 0.7f else 0.45f))
            .clickable { onClick() },
        contentAlignment = Alignment.Center,
    ) { icon() }
}

// ---------------------------------------------------------------------------
@Composable
private fun TopBar(fileName: String, onExport: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Fdc.Bg)
            .padding(horizontal = Fdc.PagePad, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            modifier = Modifier
                .size(34.dp)
                .clip(RoundedCornerShape(17.dp))
                .background(Brush.verticalGradient(listOf(Color(0xFF1E6FA8), Color(0xFF2FA3E0)))),
            contentAlignment = Alignment.Center,
        ) {
            Text("~", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }

        Column(Modifier.weight(1f).padding(start = 10.dp)) {
            Text("FreediveColor", color = Fdc.Text, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Text(
                text = "$fileName  ·  D-Log M",
                color = Fdc.TextMuted,
                fontSize = 10.sp,
                fontFamily = Fdc.Mono,
                maxLines = 1,
            )
        }

        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(Fdc.Accent)
                .clickable { onExport() },
            contentAlignment = Alignment.Center,
        ) {
            ExportIcon(Color.White)
        }
    }
}

// ---------------------------------------------------------------------------
@Composable
private fun BottomNav(selected: Int, onSelect: (Int) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Fdc.Panel)
            .padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        NavItem("Adjust", selected == 0, { onSelect(0) }) { AdjustIcon(it) }
        NavItem("HSL", selected == 1, { onSelect(1) }) { HslIcon(it) }
        NavItem("Depth", selected == 2, { onSelect(2) }) { DepthIcon(it) }
        NavItem("Clips", selected == 3, { onSelect(3) }) { ClipsIcon(it) }
    }
}

@Composable
private fun NavItem(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    icon: @Composable (Color) -> Unit,
) {
    val tint = if (selected) Fdc.Accent else Fdc.TextMuted
    Column(
        modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        icon(tint)
        Text(
            text = label,
            color = tint,
            fontSize = 10.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
            modifier = Modifier.padding(top = 2.dp),
        )
    }
}
