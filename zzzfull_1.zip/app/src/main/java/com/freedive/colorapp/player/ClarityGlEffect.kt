// ============================================================================
//  CLARITY EFFECT — pass thu hai trong chuoi hieu ung cua Media3
//  Tach rieng khoi GradeGlEffect vi unsharp mask can lay mau 8 diem lan can
//  cua ANH DA GRADE; gop chung se phai chay lai ca chuoi mau 9 lan moi pixel.
//  isNoOp(): khi Clarity ~ 0, Media3 bo qua han pass nay — khong ton GPU.
// ============================================================================
package com.freedive.colorapp.player

import android.content.Context
import androidx.media3.common.VideoFrameProcessingException
import androidx.media3.common.util.Size
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.BaseGlShaderProgram
import androidx.media3.effect.GlEffect
import androidx.media3.effect.GlShaderProgram
import kotlin.math.abs

@UnstableApi
class ClarityGlEffect(
    private val params: () -> FloatArray = { GradeBus.params },
) : GlEffect {
    override fun toGlShaderProgram(context: Context, useHdr: Boolean): GlShaderProgram =
        ClarityShaderProgram(context, useHdr, params)

    override fun isNoOp(inputWidth: Int, inputHeight: Int): Boolean =
        abs(params()[GradeBus.I.CLARITY]) < 0.001f
}

@UnstableApi
class ClarityShaderProgram(
    context: Context,
    useHdr: Boolean,
    private val paramsOf: () -> FloatArray,
) : BaseGlShaderProgram(useHdr, /* texturePoolCapacity= */ 1) {

    private companion object {
        const val VERTEX = "shaders/gl/grade_vertex.glsl"
        const val FRAGMENT = "shaders/gl/clarity_fragment.glsl"
    }

    private val program: RawGlProgram = try {
        RawGlProgram(
            context.assets.open(VERTEX).bufferedReader().use { it.readText() },
            context.assets.open(FRAGMENT).bufferedReader().use { it.readText() },
        )
    } catch (e: Exception) {
        GlStatus.report("Clarity shader: ${e.message}")
        throw VideoFrameProcessingException(e)
    }

    private var width = 1
    private var height = 1

    override fun configure(inputWidth: Int, inputHeight: Int): Size {
        width = if (inputWidth > 0) inputWidth else 1
        height = if (inputHeight > 0) inputHeight else 1
        return Size(width, height)
    }

    override fun drawFrame(inputTexId: Int, presentationTimeUs: Long) {
        try {
            program.use()
            program.setTexture2D("uTexSampler", inputTexId, /* unit= */ 0)
            program.setFloat("uClarity", paramsOf()[GradeBus.I.CLARITY])
            program.setFloat("uTexelW", 1f / width)
            program.setFloat("uTexelH", 1f / height)
            program.drawQuad()
        } catch (e: Exception) {
            GlStatus.report("Clarity drawFrame: ${e.message}")
            throw VideoFrameProcessingException(e, presentationTimeUs)
        }
    }

    override fun release() {
        super.release()
        program.release()
    }
}
