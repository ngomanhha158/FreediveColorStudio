// ============================================================================
//  TAB ADJUST — dai preset + cac slider Layer 1 / Layer 2
//  Mau track mang y nghia cong cu theo mockup: Temperature cam, Tint magenta,
//  Red Recovery gradient do, Anti-Green xanh la. Nhan trai — gia tri phai.
//  Nut mat o tieu de moi lop de tat/bat nhanh ma khong mat gia tri da chinh.
// ============================================================================
package com.freedive.colorapp.ui.compose

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.freedive.colorapp.grade.GradeState
import com.freedive.colorapp.ui.L

/** Mo ta mot hang slider — tach ra de tab nao cung dung lai duoc */
data class SliderSpec(
    val label: String,
    val min: Float,
    val max: Float,
    val color: Color = Fdc.Neutral,
    val colorEnd: Color? = null,
    val bipolar: Boolean = true,
    val format: (Float) -> String = ::fmtSigned,
    val get: (GradeState) -> Float,
    val set: (GradeState, Float) -> Unit,
)

/**
 * Mot hang slider. Gia tri khoi dau doc lai moi khi [rev] doi (doi clip, ap
 * preset); trong luc keo thi chi hang nay ve lai.
 */
@Composable
fun GradeSliderRow(
    spec: SliderSpec,
    grade: GradeState,
    rev: Int,
    enabled: Boolean,
    onEdited: () -> Unit,
) {
    var v by remember(rev, spec.label) { mutableFloatStateOf(spec.get(grade)) }
    FdcSlider(
        label = spec.label,
        value = v,
        range = spec.min..spec.max,
        trackColor = spec.color,
        trackColorEnd = spec.colorEnd,
        bipolar = spec.bipolar,
        format = spec.format,
        enabled = enabled,
        onValueChange = { nv ->
            v = nv
            spec.set(grade, nv)
            onEdited()
        },
    )
}

// ---------------------------------------------------------------------------
@Composable
fun AdjustTab(ui: FdcUiState, modifier: Modifier = Modifier) {
    val g = ui.grade
    val rev = ui.rev

    val layer1 = remember {
        listOf(
            SliderSpec("Temperature", -1f, 1f, Fdc.Temperature,
                get = { it.temp }, set = { s, v -> s.temp = v }),
            SliderSpec("Tint", -1f, 1f, Fdc.Tint,
                get = { it.tint }, set = { s, v -> s.tint = v }),
            SliderSpec("Exposure", -2f, 2f, Fdc.Neutral, format = ::fmtEv,
                get = { it.ev }, set = { s, v -> s.ev = v }),
            SliderSpec("Contrast", -1f, 1f, Fdc.Neutral,
                get = { it.contrast }, set = { s, v -> s.contrast = v }),
            SliderSpec("Shadows", -1f, 1f, Fdc.Neutral,
                get = { it.shadows }, set = { s, v -> s.shadows = v }),
            SliderSpec("Highlights", -1f, 1f, Fdc.Neutral,
                get = { it.highlights }, set = { s, v -> s.highlights = v }),
            SliderSpec("Red Recovery", 0f, 1f, Fdc.RedRecovery, Fdc.RedLight,
                bipolar = false,
                get = { it.redRecovery }, set = { s, v -> s.redRecovery = v }),
            SliderSpec("Anti Green", 0f, 1f, Fdc.AntiGreen, bipolar = false,
                get = { it.antiGreen }, set = { s, v -> s.antiGreen = v }),
        )
    }

    LazyColumn(
        modifier = modifier.fillMaxWidth(),
        contentPadding = PaddingValues(bottom = 24.dp),
    ) {
        item { SectionTitle(L.t("TONE MAP", "TONE MAP")) }
        item {
            ToggleRow(
                text = if (g.filmicTonemap)
                    L.t("Filmic AgX — vùng sáng có vai, không cắt ngọn",
                        "Filmic AgX — highlights roll off instead of clipping")
                else
                    L.t("Chuyển thẳng Rec.709 (như bản cũ)",
                        "Straight to Rec.709 (legacy)"),
                on = g.filmicTonemap,
            ) { g.filmicTonemap = !g.filmicTonemap; ui.onGradeEdited(); ui.refreshAll() }
        }

        item {
            LayerHeader(
                title = "LAYER 1 · PRIMARY",
                visible = g.l1On,
                onToggle = { g.l1On = !g.l1On; ui.onGradeEdited(); ui.refreshAll() },
            )
        }
        items(layer1) { spec ->
            Box(Modifier.padding(horizontal = Fdc.PagePad)) {
                GradeSliderRow(spec, g, rev, g.l1On, ui.onGradeEdited)
            }
        }

        item {
            LayerHeader(
                title = "LAYER 2 · LUT ENGINE",
                visible = g.l2On,
                onToggle = { g.l2On = !g.l2On; ui.onGradeEdited(); ui.refreshAll() },
            )
        }
        item {
            Box(Modifier.padding(horizontal = Fdc.PagePad)) {
                GradeSliderRow(
                    SliderSpec("LUT Mix", 0f, 1f, Fdc.Accent, bipolar = false,
                        get = { it.lutIntensity }, set = { s, v -> s.lutIntensity = v }),
                    g, rev, g.l2On, ui.onGradeEdited,
                )
            }
        }
        item {
            Box(Modifier.padding(horizontal = Fdc.PagePad)) {
                GradeSliderRow(
                    SliderSpec("LUT Luma Protect", 0f, 1f, Fdc.Temperature, bipolar = false,
                        get = { it.lumaProtect }, set = { s, v -> s.lumaProtect = v }),
                    g, rev, g.l2On, ui.onGradeEdited,
                )
            }
        }
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = Fdc.PagePad, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = if (g.lutPath.isEmpty())
                        L.t("Chưa nạp LUT nào", "No LUT loaded")
                    else java.io.File(g.lutPath).nameWithoutExtension,
                    color = Fdc.TextDim, fontSize = 12.sp, maxLines = 1,
                    modifier = Modifier.weight(1f),
                )
                SmallButton(L.t("Nhập .cube", "Import .cube")) { ui.onPickLuts() }
            }
        }

        item {
            LayerHeader(
                title = "GLOBAL",
                visible = g.l3On,
                onToggle = { g.l3On = !g.l3On; ui.onGradeEdited(); ui.refreshAll() },
            )
        }
        item {
            Box(Modifier.padding(horizontal = Fdc.PagePad)) {
                GradeSliderRow(
                    SliderSpec("Saturation", -1f, 1f, Fdc.Neutral,
                        get = { it.globalSat }, set = { s, v -> s.globalSat = v }),
                    g, rev, g.l3On, ui.onGradeEdited,
                )
            }
        }
        item {
            Box(Modifier.padding(horizontal = Fdc.PagePad)) {
                GradeSliderRow(
                    SliderSpec("Clarity", -1f, 1f, Fdc.Neutral,
                        get = { it.clarity }, set = { s, v -> s.clarity = v }),
                    g, rev, true, ui.onGradeEdited,
                )
            }
        }
    }
}

// ---------------------------------------------------------------------------
@Composable
fun PresetStrip(ui: FdcUiState) {
    Column(Modifier.padding(top = 8.dp)) {
        Text(
            text = L.t("PRESET", "PRESETS"),
            color = Fdc.TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold,
            letterSpacing = 1.2.sp,
            modifier = Modifier.padding(start = Fdc.PagePad, bottom = 6.dp),
        )
        LazyRow(
            contentPadding = PaddingValues(horizontal = Fdc.PagePad),
            horizontalArrangement = Arrangement.spacedBy(Fdc.Gap),
        ) {
            items(PRESET_NAMES.size) { i ->
                PresetCard(
                    name = PRESET_NAMES[i],
                    depth = PRESET_DEPTHS[i],
                    swatch = presetSwatch(i),
                    selected = ui.activePreset == i,
                    onClick = { ui.onApplyPreset(i) },
                )
            }
        }
    }
}

/**
 * O mau dai dien cho tung preset. Mockup dung anh xem truoc that; o day chua
 * co anh nen ve dai chuyen mau theo dung "chat" cua preset — de con hon lay
 * mot anh bat ky lam nguoi dung tuong day la khung hinh cua ho.
 */
private fun presetSwatch(index: Int): Brush = when (index) {
    0 -> Brush.verticalGradient(listOf(Color(0xFF0E5C4A), Color(0xFF2FBF8F)))  // Deep Emerald
    1 -> Brush.verticalGradient(listOf(Color(0xFF0B6A7A), Color(0xFF48D6E8)))  // Tropical Cyan
    2 -> Brush.verticalGradient(listOf(Color(0xFF06285C), Color(0xFF2E6FD0)))  // Deep Sea Blue
    3 -> Brush.verticalGradient(listOf(Color(0xFF10303A), Color(0xFF3E7C74)))  // Indo Moody
    else -> Brush.verticalGradient(listOf(Color(0xFF0A5E86), Color(0xFF56E0C8))) // Social Vibrant
}

@Composable
private fun PresetCard(
    name: String,
    depth: String,
    swatch: Brush,
    selected: Boolean,
    onClick: () -> Unit,
) {
    Column(
        modifier = Modifier
            .width(96.dp)
            .clip(RoundedCornerShape(Fdc.Radius))
            .background(if (selected) Fdc.CardHi else Fdc.Card)
            .clickable { onClick() }
            .padding(6.dp),
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(swatch),
        )
        Text(
            text = name,
            color = if (selected) Fdc.Text else Fdc.TextDim,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 2,
            modifier = Modifier.padding(top = 4.dp),
        )
        Text(text = depth, color = Fdc.TextMuted, fontSize = 9.sp, fontFamily = Fdc.Mono)
    }
}

// ---------------------------------------------------------------------------
@Composable
fun LayerHeader(title: String, visible: Boolean, onToggle: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = Fdc.PagePad, end = Fdc.PagePad, top = 16.dp, bottom = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = title,
            color = Fdc.TextMuted,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.2.sp,
            modifier = Modifier.weight(1f),
        )
        Box(
            modifier = Modifier
                .size(28.dp)
                .clip(RoundedCornerShape(8.dp))
                .clickable { onToggle() },
            contentAlignment = Alignment.Center,
        ) {
            EyeIcon(open = visible)
        }
    }
}

@Composable
fun SmallButton(text: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(Fdc.RadiusChip))
            .background(Fdc.Card)
            .clickable { onClick() }
            .padding(horizontal = 12.dp, vertical = 7.dp),
    ) {
        Text(text, color = Fdc.TextDim, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}
