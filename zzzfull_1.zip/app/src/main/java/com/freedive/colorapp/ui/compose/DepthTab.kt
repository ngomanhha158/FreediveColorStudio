// ============================================================================
//  TAB DEPTH — grade theo do sau
//  Cac preset trong freediving_color_presets.json deu gan voi mot khoang do sau
//  (Deep Emerald 20–25 m, Tropical Cyan 5–10 m, Deep Sea Blue 30 m+): cang sau
//  thi mat do do cang nhieu, phai bu Red Recovery manh hon. Tab nay cho chon
//  theo do sau thay vi theo ten preset.
//
//  Phan duoi la KEYFRAME: mot lan lan xuong thi do sau doi lien tuc trong cung
//  mot clip, nen grade dau clip va cuoi clip khong the giong nhau. Ghi hai moc
//  roi bat noi suy.
// ============================================================================
package com.freedive.colorapp.ui.compose

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.freedive.colorapp.ui.L

@Composable
fun DepthTab(ui: FdcUiState, modifier: Modifier = Modifier) {
    val g = ui.grade
    val rev = ui.rev

    val depthSliders = remember {
        listOf(
            SliderSpec("Red Recovery", 0f, 1f, Fdc.RedRecovery, Fdc.RedLight, bipolar = false,
                get = { it.redRecovery }, set = { s, v -> s.redRecovery = v }),
            SliderSpec("Anti Green", 0f, 1f, Fdc.AntiGreen, bipolar = false,
                get = { it.antiGreen }, set = { s, v -> s.antiGreen = v }),
            SliderSpec("Temperature", -1f, 1f, Fdc.Temperature,
                get = { it.temp }, set = { s, v -> s.temp = v }),
        )
    }

    LazyColumn(modifier.fillMaxWidth(), contentPadding = PaddingValues(bottom = 24.dp)) {
        item { SectionTitle(L.t("CHỌN THEO ĐỘ SÂU", "PICK BY DEPTH")) }
        item {
            Column(Modifier.padding(horizontal = Fdc.PagePad)) {
                DepthRow("5 – 10 m", PRESET_NAMES[1],
                    L.t("Nước nông, còn nhiều đỏ", "Shallow, red still present"),
                    ui.activePreset == 1) { ui.onApplyPreset(1) }
                DepthRow("20 – 25 m", PRESET_NAMES[0],
                    L.t("Mất phổ đỏ nghiêm trọng, ám xanh lá", "Heavy red loss, green cast"),
                    ui.activePreset == 0) { ui.onApplyPreset(0) }
                DepthRow("30 m +", PRESET_NAMES[2],
                    L.t("Chỉ còn xanh lam, tương phản thấp", "Blue only, low contrast"),
                    ui.activePreset == 2) { ui.onApplyPreset(2) }
            }
        }

        item { SectionTitle(L.t("BÙ THEO ĐỘ SÂU", "DEPTH COMPENSATION")) }
        item {
            Column(Modifier.padding(horizontal = Fdc.PagePad)) {
                depthSliders.forEach { s ->
                    GradeSliderRow(s, g, rev, g.l1On, ui.onGradeEdited)
                }
            }
        }

        item { SectionTitle(L.t("KEYFRAME THEO TIẾN TRÌNH CLIP", "KEYFRAMES ALONG THE CLIP")) }
        item {
            Column(Modifier.padding(horizontal = Fdc.PagePad)) {
                Text(
                    L.t("Ghi grade ở đầu và cuối clip, app tự nội suy phần giữa — dùng khi một lần lặn đi qua nhiều mức sâu.",
                        "Save the grade at the start and end; the app interpolates in between — for a dive that spans several depths."),
                    color = Fdc.TextMuted, fontSize = 11.sp,
                    modifier = Modifier.padding(bottom = 8.dp),
                )
                Row(horizontalArrangement = Arrangement.spacedBy(Fdc.Gap)) {
                    SmallButton(L.t("Ghi KF đầu", "Set start KF")) { ui.onSetKeyframe(true) }
                    SmallButton(L.t("Ghi KF cuối", "Set end KF")) { ui.onSetKeyframe(false) }
                    SmallButton(
                        if (ui.keyframesEnabled) L.t("Tắt nội suy", "Disable")
                        else L.t("Bật nội suy", "Enable")
                    ) { ui.onToggleKeyframes() }
                }
            }
        }
    }
}

@Composable
private fun DepthRow(
    depth: String,
    preset: String,
    note: String,
    selected: Boolean,
    onClick: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .clip(RoundedCornerShape(Fdc.Radius))
            .background(if (selected) Fdc.CardHi else Fdc.Card)
            .clickable { onClick() }
            .padding(horizontal = 12.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = depth,
            color = if (selected) Fdc.Accent else Fdc.TextDim,
            fontSize = 14.sp,
            fontFamily = Fdc.Mono,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(end = 14.dp),
        )
        Column(Modifier.weight(1f)) {
            Text(preset, color = Fdc.Text, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Text(note, color = Fdc.TextMuted, fontSize = 10.sp, maxLines = 2)
        }
        Box(Modifier.padding(start = 8.dp)) { DepthIcon(if (selected) Fdc.Accent else Fdc.TextMuted) }
    }
}
