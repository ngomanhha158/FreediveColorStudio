// ============================================================================
//  RAW GL PROGRAM — tu quan ly chuong trinh GL, KHONG dung GlProgram cua Media3
//
//  Vi sao khong dung GlProgram: no liet ke moi uniform dang hoat dong roi bind
//  tung cai theo mot bang kieu chi gom float / vec2..4 / mat3..4 / sampler2D /
//  samplerExternalOES. Shader grade co "uniform sampler3D uLutTex" (LUT .cube),
//  gap kieu ngoai bang -> bind() nem IllegalStateException ngay frame dau ->
//  sap ca pipeline video (man hinh den, vi tri dung o 00:00).
//
//  Lop nay chi lam dung phan can thiet: bien dich, link, cache vi tri uniform,
//  ve mot quad phu kin khung. Bao loi bien dich shader ra ngoai de hien len UI.
// ============================================================================
package com.freedive.colorapp.player

import android.opengl.GLES20
import android.opengl.GLES30
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer

class GlProgramException(message: String) : Exception(message)

class RawGlProgram(vertexSrc: String, fragmentSrc: String) {

    private val programId: Int
    private val locations = HashMap<String, Int>()
    private val positionHandle: Int

    private companion object {
        /** Quad phu kin khung hinh (NDC), ve bang TRIANGLE_STRIP 4 dinh */
        val QUAD = floatArrayOf(
            -1f, -1f, 0f, 1f,
             1f, -1f, 0f, 1f,
            -1f,  1f, 0f, 1f,
             1f,  1f, 0f, 1f,
        )
    }

    private val quadBuffer: FloatBuffer =
        ByteBuffer.allocateDirect(QUAD.size * 4).order(ByteOrder.nativeOrder())
            .asFloatBuffer().apply { put(QUAD); position(0) }

    init {
        val vs = compile(GLES20.GL_VERTEX_SHADER, vertexSrc, "vertex")
        val fs = compile(GLES20.GL_FRAGMENT_SHADER, fragmentSrc, "fragment")
        programId = GLES20.glCreateProgram()
        if (programId == 0) throw GlProgramException("glCreateProgram tra ve 0")
        GLES20.glAttachShader(programId, vs)
        GLES20.glAttachShader(programId, fs)
        GLES20.glLinkProgram(programId)
        val status = IntArray(1)
        GLES20.glGetProgramiv(programId, GLES20.GL_LINK_STATUS, status, 0)
        if (status[0] != GLES20.GL_TRUE) {
            val log = GLES20.glGetProgramInfoLog(programId)
            GLES20.glDeleteProgram(programId)
            throw GlProgramException("Link chuong trinh that bai: $log")
        }
        // Shader con da duoc gan vao chuong trinh, xoa doi tuong shader la du
        GLES20.glDeleteShader(vs)
        GLES20.glDeleteShader(fs)

        positionHandle = GLES20.glGetAttribLocation(programId, "aFramePosition")
        if (positionHandle < 0)
            throw GlProgramException("Khong tim thay thuoc tinh aFramePosition")
    }

    private fun compile(type: Int, src: String, label: String): Int {
        val id = GLES20.glCreateShader(type)
        if (id == 0) throw GlProgramException("glCreateShader($label) tra ve 0")
        GLES20.glShaderSource(id, src)
        GLES20.glCompileShader(id)
        val status = IntArray(1)
        GLES20.glGetShaderiv(id, GLES20.GL_COMPILE_STATUS, status, 0)
        if (status[0] != GLES20.GL_TRUE) {
            val log = GLES20.glGetShaderInfoLog(id)
            GLES20.glDeleteShader(id)
            throw GlProgramException("Bien dich shader $label that bai: $log")
        }
        return id
    }

    fun use() = GLES20.glUseProgram(programId)

    private fun loc(name: String): Int =
        locations.getOrPut(name) { GLES20.glGetUniformLocation(programId, name) }

    fun setFloat(name: String, v: Float) {
        val l = loc(name); if (l >= 0) GLES20.glUniform1f(l, v)
    }

    fun setVec3(name: String, x: Float, y: Float, z: Float) {
        val l = loc(name); if (l >= 0) GLES20.glUniform3f(l, x, y, z)
    }

    fun setVec4(name: String, x: Float, y: Float, z: Float, w: Float) {
        val l = loc(name); if (l >= 0) GLES20.glUniform4f(l, x, y, z, w)
    }

    /** Gan texture 2D vao mot don vi texture roi tro uniform vao don vi do */
    fun setTexture2D(name: String, texId: Int, unit: Int) {
        val l = loc(name); if (l < 0) return
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0 + unit)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texId)
        GLES20.glUniform1i(l, unit)
    }

    /** Gan texture 3D — day chinh la thu GlProgram cua Media3 khong lam duoc */
    fun setTexture3D(name: String, texId: Int, unit: Int) {
        val l = loc(name); if (l < 0) return
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0 + unit)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_3D, texId)
        GLES20.glUniform1i(l, unit)
    }

    fun drawQuad() {
        quadBuffer.position(0)
        GLES20.glEnableVertexAttribArray(positionHandle)
        GLES20.glVertexAttribPointer(
            positionHandle, /* size= */ 4, GLES20.GL_FLOAT,
            /* normalized= */ false, /* stride= */ 0, quadBuffer
        )
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        GLES20.glDisableVertexAttribArray(positionHandle)
    }

    fun release() {
        if (programId != 0) GLES20.glDeleteProgram(programId)
    }
}
