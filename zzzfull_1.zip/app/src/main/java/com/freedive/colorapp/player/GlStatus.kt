// ============================================================================
//  GL STATUS — kenh bao loi tu GL thread ve UI
//  Loi trong pipeline hieu ung xay ra tren GL thread cua Media3; neu khong dan
//  ve UI thi nguoi dung chi thay man hinh den, khong biet vi sao (dung nhu lan
//  hong sampler3D vua roi). Lop nay giu thong bao gan nhat de MainActivity hien.
// ============================================================================
package com.freedive.colorapp.player

object GlStatus {
    @Volatile
    var lastError: String? = null
        private set

    /** Goi tu GL thread */
    fun report(message: String) { lastError = message }

    fun clear() { lastError = null }
}
