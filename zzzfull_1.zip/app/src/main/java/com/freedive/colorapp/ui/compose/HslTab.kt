// ============================================================================
//  TAB HSL — tach mau theo dai, va Skin Lock Mask
//  Hai nhom quan trong nhat khi grade duoi nuoc:
//   · TONG DA (Red + Orange) — thu de bao ve khoi bi keo theo mau nuoc
//   · MAU NUOC (Cyan + Blue)  — thu duoc chinh manh tay
//  Moi slider chinh DONG THOI hai dai lien nhau (R+O hoac C+B) vi ranh gioi
//  giua chung khong co y nghia thuc te tren da nguoi hay khoi nuoc.
// ============================================================================
package com.freedive.colorapp.ui.compose

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.freedive.colorapp.ui.L

@Composable
fun HslTab(ui: FdcUiState, modifier: Modifier = Modifier) {
    val g = ui.grade
    val rev = ui.rev

    val skin = remember {
        listOf(
            SliderSpec("Hue", -30f, 30f, Color(0xFFFFB27A), format = ::fmtDeg,
                get = { it.hsl[0].hue }, set = { s, v -> s.hsl[0].hue = v; s.hsl[1].hue = v }),
            SliderSpec("Saturation", -1f, 1f, Color(0xFFFFB27A),
                get = { it.hsl[0].sat }, set = { s, v -> s.hsl[0].sat = v; s.hsl[1].sat = v }),
            SliderSpec("Luma", -1f, 1f, Color(0xFFFFB27A),
                get = { it.hsl[0].luma }, set = { s, v -> s.hsl[0].luma = v; s.hsl[1].luma = v }),
        )
    }
    val water = remember {
        listOf(
            SliderSpec("Hue", -30f, 30f, Color(0xFF4FD8E8), format = ::fmtDeg,
                get = { it.hsl[4].hue }, set = { s, v -> s.hsl[4].hue = v; s.hsl[5].hue = v }),
            SliderSpec("Saturation", -1f, 1f, Color(0xFF4FD8E8),
                get = { it.hsl[4].sat }, set = { s, v -> s.hsl[4].sat = v; s.hsl[5].sat = v }),
            SliderSpec("Luma", -1f, 1f, Color(0xFF4FD8E8),
                get = { it.hsl[4].luma }, set = { s, v -> s.hsl[4].luma = v; s.hsl[5].luma = v }),
        )
    }
    val lock = remember {
        listOf(
            SliderSpec("Target hue", 0f, 60f, Fdc.Accent, bipolar = false, format = ::fmtDeg,
                get = { it.skinLockHue }, set = { s, v -> s.skinLockHue = v }),
            SliderSpec("Tolerance", 5f, 40f, Fdc.Accent, bipolar = false, format = ::fmtDeg,
                get = { it.skinLockTol }, set = { s, v -> s.skinLockTol = v }),
            SliderSpec("Feather", 5f, 45f, Fdc.Accent, bipolar = false, format = ::fmtDeg,
                get = { it.skinLockFeather }, set = { s, v -> s.skinLockFeather = v }),
            SliderSpec("Strength", 0f, 1f, Fdc.Accent, bipolar = false,
                get = { it.skinLockStrength }, set = { s, v -> s.skinLockStrength = v }),
        )
    }

    LazyColumn(modifier.fillMaxWidth(), contentPadding = PaddingValues(bottom = 24.dp)) {
        item { SectionTitle(L.t("TÔNG DA · ORANGE / RED", "SKIN TONES · ORANGE / RED")) }
        item {
            ToggleRow(
                text = L.t("Bảo vệ tông da", "Skin tone protection"),
                on = g.skinProtect,
            ) { g.skinProtect = !g.skinProtect; ui.onGradeEdited(); ui.refreshAll() }
        }
        items(skin) { s ->
            Box(Modifier.padding(horizontal = Fdc.PagePad)) {
                GradeSliderRow(s, g, rev, g.l3On, ui.onGradeEdited)
            }
        }

        item { SectionTitle(L.t("MÀU NƯỚC · CYAN / BLUE", "WATER · CYAN / BLUE")) }
        items(water) { s ->
            Box(Modifier.padding(horizontal = Fdc.PagePad)) {
                GradeSliderRow(s, g, rev, g.l3On, ui.onGradeEdited)
            }
        }

        item { SectionTitle(L.t("SKIN LOCK MASK", "SKIN LOCK MASK")) }
        item {
            ToggleRow(
                text = L.t("Bật khoá tông da", "Enable skin lock"),
                on = g.skinLock,
            ) { g.skinLock = !g.skinLock; ui.onGradeEdited(); ui.refreshAll() }
        }
        items(lock) { s ->
            Box(Modifier.padding(horizontal = Fdc.PagePad)) {
                GradeSliderRow(s, g, rev, g.skinLock, ui.onGradeEdited)
            }
        }
    }
}

@Composable
fun SectionTitle(text: String) {
    Text(
        text = text,
        color = Fdc.TextMuted,
        fontSize = 10.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.2.sp,
        modifier = Modifier.padding(start = Fdc.PagePad, top = 16.dp, bottom = 4.dp),
    )
}

@Composable
fun ToggleRow(text: String, on: Boolean, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = Fdc.PagePad, vertical = 4.dp)
            .clip(RoundedCornerShape(Fdc.RadiusChip))
            .background(if (on) Fdc.CardHi else Fdc.Card)
            .clickable { onClick() }
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = text,
            color = if (on) Fdc.Text else Fdc.TextDim,
            fontSize = 13.sp,
            modifier = Modifier.weight(1f),
        )
        EyeIcon(open = on)
    }
}
