// ============================================================================
//  FDC ICONS — bieu tuong ve tay bang Canvas
//  Khong keo them thu vien material-icons-extended chi vi vai bieu tuong, va
//  bo icon mac dinh cua Material cung khong co hinh "nua mat trang" / "kim
//  cuong" nhu mockup. Ve tay bam sat mockup hon va khong ton them dung luong.
// ============================================================================
package com.freedive.colorapp.ui.compose

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp

/** Con mat — mo (lop dang bat) / gach cheo (lop dang tat) */
@Composable
fun EyeIcon(open: Boolean, tint: Color = if (open) Fdc.Accent else Fdc.TextMuted) {
    Canvas(Modifier.size(18.dp)) {
        val w = size.width
        val h = size.height
        val p = Path().apply {
            moveTo(w * 0.06f, h * 0.5f)
            quadraticBezierTo(w * 0.5f, h * 0.08f, w * 0.94f, h * 0.5f)
            quadraticBezierTo(w * 0.5f, h * 0.92f, w * 0.06f, h * 0.5f)
            close()
        }
        drawPath(p, tint, style = Stroke(width = w * 0.09f))
        drawCircle(tint, radius = w * 0.16f, center = Offset(w * 0.5f, h * 0.5f))
        if (!open) {
            drawLine(
                tint,
                start = Offset(w * 0.12f, h * 0.85f),
                end = Offset(w * 0.88f, h * 0.15f),
                strokeWidth = w * 0.10f,
            )
        }
    }
}

/** Adjust — nua mat trang (vong tron nua sang nua toi) */
@Composable
fun AdjustIcon(tint: Color) {
    Canvas(Modifier.size(22.dp)) {
        val r = size.minDimension / 2f * 0.86f
        val c = Offset(size.width / 2f, size.height / 2f)
        drawCircle(tint, radius = r, center = c, style = Stroke(width = size.width * 0.09f))
        val half = Path().apply {
            addArc(
                Rect(c.x - r, c.y - r, c.x + r, c.y + r),
                startAngleDegrees = 90f,
                sweepAngleDegrees = 180f,
            )
            close()
        }
        drawPath(half, tint)
    }
}

/** HSL — bieu do tron chia mui */
@Composable
fun HslIcon(tint: Color) {
    Canvas(Modifier.size(22.dp)) {
        val r = size.minDimension / 2f * 0.86f
        val c = Offset(size.width / 2f, size.height / 2f)
        drawCircle(tint, radius = r, center = c, style = Stroke(width = size.width * 0.09f))
        val wedge = Path().apply {
            moveTo(c.x, c.y)
            arcTo(
                Rect(c.x - r, c.y - r, c.x + r, c.y + r),
                startAngleDegrees = -90f,
                sweepAngleDegrees = 110f,
                forceMoveTo = false,
            )
            close()
        }
        drawPath(wedge, tint)
    }
}

/** Depth — hinh kim cuong (do sau) */
@Composable
fun DepthIcon(tint: Color) {
    Canvas(Modifier.size(22.dp)) {
        val w = size.width
        val h = size.height
        val p = Path().apply {
            moveTo(w * 0.5f, h * 0.08f)
            lineTo(w * 0.92f, h * 0.5f)
            lineTo(w * 0.5f, h * 0.92f)
            lineTo(w * 0.08f, h * 0.5f)
            close()
        }
        drawPath(p, tint, style = Stroke(width = w * 0.09f))
    }
}

/** Clips — danh sach */
@Composable
fun ClipsIcon(tint: Color) {
    Canvas(Modifier.size(22.dp)) {
        val w = size.width
        val h = size.height
        val sw = w * 0.09f
        for (i in 0..2) {
            val y = h * (0.26f + i * 0.24f)
            drawCircle(tint, radius = sw * 0.85f, center = Offset(w * 0.16f, y))
            drawLine(
                tint,
                start = Offset(w * 0.36f, y),
                end = Offset(w * 0.90f, y),
                strokeWidth = sw,
            )
        }
    }
}

/** Xuat file — mui ten xuong khay */
@Composable
fun ExportIcon(tint: Color) {
    Canvas(Modifier.size(20.dp)) {
        val w = size.width
        val h = size.height
        val sw = w * 0.10f
        drawLine(tint, Offset(w * 0.5f, h * 0.10f), Offset(w * 0.5f, h * 0.62f), strokeWidth = sw)
        val arrow = Path().apply {
            moveTo(w * 0.28f, h * 0.44f)
            lineTo(w * 0.5f, h * 0.68f)
            lineTo(w * 0.72f, h * 0.44f)
        }
        drawPath(arrow, tint, style = Stroke(width = sw))
        drawLine(tint, Offset(w * 0.16f, h * 0.86f), Offset(w * 0.84f, h * 0.86f), strokeWidth = sw)
    }
}
