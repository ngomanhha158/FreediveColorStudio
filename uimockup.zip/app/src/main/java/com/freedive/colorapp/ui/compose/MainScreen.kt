// ============================================================================
//  MAIN SCREEN — bo cuc tong theo mockup
//    Thanh tren (logo · ten app · ten file · nut Xuat)
//    Khung phat 16:9 (so sanh Before/After + Scopes noi)
//    Dai preset  — nam NGOAI tab, hien o ca Adjust lan Clips
//    Noi dung tab
//    Thanh dieu huong duoi: Adjust · HSL · Depth · Clips
// ============================================================================
package com.freedive.colorapp.ui.compose

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.util.UnstableApi
import com.freedive.colorapp.player.GradePlayer
import com.freedive.colorapp.ui.L

@UnstableApi
@Composable
fun MainScreen(player: GradePlayer, ui: FdcUiState) {
    var tab by remember { mutableIntStateOf(0) }
    var showScopes by remember { mutableStateOf(true) }

    // targetSdk 36 ep edge-to-edge: neu khong tru inset thi thanh tren chui
    // duoi thanh trang thai va thanh dieu huong bi che.
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Fdc.Accent,
            background = Fdc.Bg,
            surface = Fdc.Panel,
            onBackground = Fdc.Text,
            onSurface = Fdc.Text,
        )
    ) {
    Column(
        Modifier
            .fillMaxSize()
            .background(Fdc.Bg)
            .windowInsetsPadding(WindowInsets.statusBars)
    ) {

        TopBar(
            fileName = ui.currentName.ifEmpty { L.t("Chưa chọn clip", "No clip") },
            exportSummary = ui.exportSummary,
            onExport = ui.onExport,
        )

        // ---- Khung phat 16:9 ----
        Box(Modifier.fillMaxWidth().aspectRatio(16f / 9f)) {
            SplitWipePlayer(
                gradePlayer = player,
                presetName = if (ui.activePreset >= 0) PRESET_NAMES[ui.activePreset]
                             else L.t("Gốc", "Original"),
                showScopes = showScopes,
                modifier = Modifier.fillMaxSize(),
            )
            // Nut tron goc trai-duoi: bat/tat the Scopes
            Box(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(10.dp)
                    .size(32.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color.Black.copy(alpha = 0.5f))
                    .clickable { showScopes = !showScopes },
                contentAlignment = Alignment.Center,
            ) {
                HslIcon(if (showScopes) Fdc.Accent else Fdc.TextMuted)
            }
        }

        // ---- Dong bao loi (chi hien khi co) ----
        ui.status?.let { msg ->
            Text(
                text = msg,
                color = Fdc.Warn,
                fontSize = 11.sp,
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0x22E0873A))
                    .padding(horizontal = Fdc.PagePad, vertical = 6.dp),
            )
        }

        // ---- Dai preset dung chung ----
        PresetStrip(ui)

        // ---- Noi dung tab ----
        Box(Modifier.weight(1f).fillMaxWidth()) {
            when (tab) {
                0 -> AdjustTab(ui)
                1 -> HslTab(ui)
                2 -> DepthTab(ui)
                else -> ClipsTab(ui)
            }
        }

        Box(Modifier.windowInsetsPadding(WindowInsets.navigationBars)) {
            BottomNav(selected = tab, onSelect = { tab = it })
        }
    }
    }
}

// ---------------------------------------------------------------------------
@Composable
private fun TopBar(fileName: String, exportSummary: String, onExport: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Fdc.Bg)
            .padding(horizontal = Fdc.PagePad, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        // Logo tron
        Box(
            modifier = Modifier
                .size(34.dp)
                .clip(RoundedCornerShape(17.dp))
                .background(
                    Brush.verticalGradient(listOf(Color(0xFF1E6FA8), Color(0xFF2FA3E0)))
                ),
            contentAlignment = Alignment.Center,
        ) {
            Text("~", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }

        Column(Modifier.weight(1f).padding(start = 10.dp)) {
            Text("FreediveColor", color = Fdc.Text, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Text(
                text = "$fileName  ·  D-Log M",
                color = Fdc.TextMuted,
                fontSize = 10.sp,
                fontFamily = Fdc.Mono,
                maxLines = 1,
            )
        }

        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(Fdc.Accent)
                .clickable { onExport() },
            contentAlignment = Alignment.Center,
        ) {
            ExportIcon(Color.White)
        }
    }
}

// ---------------------------------------------------------------------------
@Composable
private fun BottomNav(selected: Int, onSelect: (Int) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Fdc.Panel)
            .padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        NavItem("Adjust", selected == 0, { onSelect(0) }) { AdjustIcon(it) }
        NavItem("HSL", selected == 1, { onSelect(1) }) { HslIcon(it) }
        NavItem("Depth", selected == 2, { onSelect(2) }) { DepthIcon(it) }
        NavItem("Clips", selected == 3, { onSelect(3) }) { ClipsIcon(it) }
    }
}

@Composable
private fun NavItem(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    icon: @Composable (Color) -> Unit,
) {
    val tint = if (selected) Fdc.Accent else Fdc.TextMuted
    Column(
        modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        icon(tint)
        Text(
            text = label,
            color = tint,
            fontSize = 10.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
            modifier = Modifier.padding(top = 2.dp),
        )
    }
}
