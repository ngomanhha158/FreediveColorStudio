// ============================================================================
//  MAIN ACTIVITY — chi con lam ba viec: dung ExoPlayer, gom du lieu, va gan
//  cac hanh dong vao FdcUiState. Toan bo giao dien nam trong ui/compose.
//
//  Duong hinh anh:
//      ExoPlayer -> DefaultVideoFrameProcessor (GL ES)
//                -> GradeGlEffect  (CST + Layer 1 + LUT + Layer 3 + Before/After)
//                -> ClarityGlEffect
//                -> SurfaceView
//  Tham so mau di qua GradeBus (UI ghi -> GL thread doc), nen keo slider la doi
//  ngay ca khi video dang tam dung.
// ============================================================================
package com.freedive.colorapp

import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import com.freedive.colorapp.grade.DraftStore
import com.freedive.colorapp.grade.GradeManager
import com.freedive.colorapp.grade.GradeState
import com.freedive.colorapp.grade.KeyframeController
import com.freedive.colorapp.grade.PresetLoader
import com.freedive.colorapp.player.GlStatus
import com.freedive.colorapp.player.GradeBus
import com.freedive.colorapp.player.GradePlayer
import com.freedive.colorapp.ui.L
import com.freedive.colorapp.ui.compose.ClipItem
import com.freedive.colorapp.ui.compose.FdcUiState
import com.freedive.colorapp.ui.compose.MainScreen
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@UnstableApi
class MainActivity : ComponentActivity() {

    private lateinit var gradePlayer: GradePlayer
    private lateinit var gradeManager: GradeManager
    private lateinit var draftStore: DraftStore
    private lateinit var lutRepo: com.freedive.colorapp.lut.LutRepository
    private val ui = FdcUiState()
    private val keyframes = KeyframeController()
    private val io = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    // Keyframing: truoc day nhan tick tu decoder, nay hoi vi tri cua ExoPlayer
    private val kfHandler = Handler(Looper.getMainLooper())
    private val kfTick = object : Runnable {
        override fun run() {
            val dur = gradePlayer.player.duration
            if (dur > 0) keyframes.setDuration(dur * 1000L)
            if (keyframes.enabled && dur > 0 && gradePlayer.player.isPlaying) {
                keyframes.onFrame(gradePlayer.player.currentPosition * 1000L)
                    ?.let { GradeBus.push(it) }
            }
            kfHandler.postDelayed(this, 40)
        }
    }

    private val pickVideo =
        registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
            if (uris.isNullOrEmpty()) return@registerForActivityResult
            uris.forEach { uri ->
                runCatching {
                    contentResolver.takePersistableUriPermission(
                        uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                }
                addClip(uri)
            }
            uris.firstOrNull()?.let { selectClip(it) }
        }

    private val pickLuts =
        registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
            if (uris.isNullOrEmpty()) return@registerForActivityResult
            val imported = lutRepo.import(uris)
            if (imported.isEmpty()) {
                toast(L.t("Không nhập được file .cube hợp lệ", "No valid .cube file imported"))
            } else {
                ui.grade.lutPath = imported.first().absolutePath
                pushGrade()
                ui.refreshAll()
                toast(L.t("Đã nhập ${imported.size} LUT", "Imported ${imported.size} LUT(s)"))
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        L.init(this)
        gradeManager = GradeManager(this)
        draftStore = DraftStore(this)
        lutRepo = com.freedive.colorapp.lut.LutRepository(this)
        gradePlayer = GradePlayer(this)

        gradePlayer.player.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                val gl = GlStatus.lastError
                val cause = error.cause
                ui.status = buildString {
                    append("⚠ ").append(error.errorCodeName)
                    if (cause != null) {
                        append(" · ").append(cause.javaClass.simpleName)
                        cause.message?.let { append(": ").append(it) }
                    }
                    gl?.let { append("\nGL: ").append(it) }
                }
            }
        })

        wireActions()
        setContent { MainScreen(gradePlayer, ui) }
        kfHandler.post(kfTick)

        // Khoi phuc phien truoc
        draftStore.load()?.let { (clips, grades) ->
            gradeManager.restore(grades)
            clips.forEach { addClip(it) }
            clips.firstOrNull()?.let { selectClip(it) }
        }
    }

    // ------------------------------------------------------------------------
    private fun wireActions() {
        ui.onPickVideo = { pickVideo.launch(arrayOf("video/*")) }
        ui.onPickLuts = {
            pickLuts.launch(arrayOf("application/octet-stream", "text/plain", "*/*"))
        }
        ui.onSelectClip = { uri -> selectClip(uri) }
        ui.onApplyPreset = { i -> applyPreset(i) }
        ui.onGradeEdited = { pushGrade() }

        ui.onCopyGrade = {
            val uri = ui.currentUri
            if (uri == null) toast(L.t("Chưa có clip", "No clip loaded"))
            else if (gradeManager.copyAttributes(uri))
                toast(L.t("Đã copy 3 layer", "Copied all 3 layers"))
        }
        ui.onPasteGrade = {
            val uri = ui.currentUri
            if (uri == null) toast(L.t("Chưa có clip", "No clip loaded"))
            else if (!gradeManager.hasClipboard()) toast(L.t("Clipboard trống", "Clipboard empty"))
            else {
                gradeManager.pasteToAll(setOf(uri), null)
                ui.grade = gradeManager.stateFor(uri)
                pushGrade(); ui.refreshAll()
                toast(L.t("Đã dán grade", "Grade pasted"))
            }
        }
        ui.onPasteAll = {
            if (!gradeManager.hasClipboard()) toast(L.t("Clipboard trống", "Clipboard empty"))
            else {
                val n = gradeManager.pasteToAll(ui.clips.map { it.uri }.toSet(), ui.currentUri)
                ui.currentUri?.let { ui.grade = gradeManager.stateFor(it) }
                pushGrade(); ui.refreshAll()
                toast(L.t("Đã áp grade cho $n clip", "Applied grade to $n clip(s)"))
            }
        }
        ui.onResetGrade = {
            ui.grade = GradeState()
            ui.activePreset = -1
            ui.currentUri?.let { gradeManager.put(it, ui.grade) }
            pushGrade(); ui.refreshAll()
            toast(L.t("Đã đưa về mặc định", "Reset to default"))
        }

        ui.onSetKeyframe = { isStart ->
            if (isStart) keyframes.setStartKeyframe(ui.grade)
            else keyframes.setEndKeyframe(ui.grade)
            toast(
                if (isStart) L.t("Đã ghi keyframe đầu", "Start keyframe saved")
                else L.t("Đã ghi keyframe cuối", "End keyframe saved")
            )
        }
        ui.onToggleKeyframes = {
            if (!keyframes.hasBoth()) toast(L.t("Cần đủ 2 keyframe", "Need both keyframes"))
            else {
                keyframes.enabled = !keyframes.enabled
                ui.keyframesEnabled = keyframes.enabled
                ui.refreshAll()
                toast(
                    if (keyframes.enabled) L.t("Nội suy BẬT", "Interpolation ON")
                    else L.t("Nội suy tắt", "Interpolation off")
                )
            }
        }

        ui.onExport = {
            toast(L.t(
                "Xuất file đang chuyển sang Media3 Transformer — chưa dùng được ở bản này",
                "Export is being migrated to Media3 Transformer — not available yet"
            ))
        }
        ui.onExportAll = ui.onExport
    }

    // ------------------------------------------------------------------------
    private fun pushGrade() {
        GradeBus.push(ui.grade)
        ui.currentUri?.let { gradeManager.put(it, ui.grade) }
        draftStore.scheduleSave(ui.clips.map { it.uri }, gradeManager.snapshot())
    }

    private fun applyPreset(index: Int) {
        val states = runCatching { PresetLoader.states(this) }.getOrNull() ?: return
        val g = states.getOrNull(index) ?: return
        ui.grade = GradeState.fromJson(g.toJson())    // ban sao doc lap voi cache preset
        ui.activePreset = index
        pushGrade()
        ui.refreshAll()
    }

    private fun selectClip(uri: Uri) {
        ui.currentUri = uri
        ui.currentName = ui.clips.firstOrNull { it.uri == uri }?.name ?: displayName(uri)
        ui.grade = gradeManager.stateFor(uri)
        GradeBus.push(ui.grade)
        GradeBus.setWipe(0f)
        keyframes.enabled = false
        ui.keyframesEnabled = false
        ui.status = null
        ui.refreshAll()
        gradePlayer.open(uri, autoPlay = true)
    }

    /** Doc ten / thoi luong / anh dai dien / toa do o luong nen roi cap nhat vao danh sach */
    private fun addClip(uri: Uri) {
        if (ui.clips.any { it.uri == uri }) return
        val name = displayName(uri)
        ui.clips.add(ClipItem(uri = uri, name = name))
        io.launch {
            var dur = 0L
            var thumb: Bitmap? = null
            var loc: String? = null
            val mmr = MediaMetadataRetriever()
            runCatching {
                mmr.setDataSource(this@MainActivity, uri)
                dur = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                    ?.toLongOrNull() ?: 0L
                thumb = mmr.getFrameAtTime(0)
                loc = formatLocation(
                    mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_LOCATION)
                )
            }
            runCatching { mmr.release() }
            withContext(Dispatchers.Main) {
                val i = ui.clips.indexOfFirst { it.uri == uri }
                if (i >= 0) {
                    ui.clips[i] = ui.clips[i].copy(
                        durationMs = dur, thumbnail = thumb, location = loc
                    )
                }
                if (ui.currentUri == uri) ui.currentName = name
            }
        }
    }

    /**
     * METADATA_KEY_LOCATION tra ve dang ISO-6709: "+10.2270+103.9670/".
     * Chi hien toa do — khong tra cuu ten dia danh (can mang, va doan sai thi
     * te hon la khong hien gi).
     */
    private fun formatLocation(raw: String?): String? {
        if (raw.isNullOrBlank()) return null
        val m = Regex("([+-]\\d+(?:\\.\\d+)?)([+-]\\d+(?:\\.\\d+)?)").find(raw) ?: return null
        val lat = m.groupValues[1].toDoubleOrNull() ?: return null
        val lon = m.groupValues[2].toDoubleOrNull() ?: return null
        val ns = if (lat >= 0) "N" else "S"
        val ew = if (lon >= 0) "E" else "W"
        return "%.3f°%s  %.3f°%s".format(kotlin.math.abs(lat), ns, kotlin.math.abs(lon), ew)
    }

    private fun displayName(uri: Uri): String {
        var found: String? = null
        runCatching {
            contentResolver.query(uri, null, null, null, null)?.use { c ->
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (i >= 0 && c.moveToFirst()) found = c.getString(i)
            }
        }
        return found ?: uri.lastPathSegment?.substringAfterLast('/') ?: "clip"
    }

    override fun onPause() {
        gradePlayer.player.playWhenReady = false
        draftStore.saveNow(ui.clips.map { it.uri }, gradeManager.snapshot())
        super.onPause()
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    override fun onDestroy() {
        kfHandler.removeCallbacks(kfTick)
        gradePlayer.release()
        super.onDestroy()
    }
}
