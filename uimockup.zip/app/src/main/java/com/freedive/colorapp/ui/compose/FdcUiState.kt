// ============================================================================
//  FDC UI STATE — cau noi giua Compose va phan con lai cua app
//  GradeState la data class co the sua tai cho (khong phai snapshot state cua
//  Compose). Neu bo no vao mutableStateOf roi copy moi lan keo slider thi moi
//  frame keo se sinh mot ban sao — rat ton. Cach dung o day:
//    · GradeState giu nguyen dang doi tuong thuong, slider ghi thang vao
//    · "rev" chi tang khi CA BO gia tri doi (doi clip, ap preset, reset) de
//      moi slider doc lai gia tri khoi dau
//  Nho vay keo mot slider chi ve lai dung slider do.
// ============================================================================
package com.freedive.colorapp.ui.compose

import android.graphics.Bitmap
import android.net.Uri
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import com.freedive.colorapp.grade.GradeState

/** Mot clip trong tab Clips */
data class ClipItem(
    val uri: Uri,
    val name: String,
    val durationMs: Long = 0L,
    val thumbnail: Bitmap? = null,
    /**
     * Nhan dia diem duoi ten file (mockup: "Phu Quoc · drop-off").
     * Chi dien khi file that su co toa do GPS trong metadata; khong bia ra.
     */
    val location: String? = null,
)

/** Ten ngan cua 5 preset — lay tu freediving_color_presets.json */
val PRESET_NAMES = listOf(
    "Deep Emerald",
    "Tropical Cyan",
    "Deep Sea Blue",
    "Indo Moody",
    "Social Vibrant",
)

/** Do sau khuyen nghi cua tung preset (m) — dung cho tab Depth */
val PRESET_DEPTHS = listOf(
    "20–25 m",
    "5–10 m",
    "30 m+",
    "—",
    "—",
)

class FdcUiState {
    /** Danh sach clip da nap */
    val clips = mutableStateListOf<ClipItem>()

    var currentUri by mutableStateOf<Uri?>(null)
    var currentName by mutableStateOf("")
    var activePreset by mutableIntStateOf(-1)

    /** Grade cua clip dang chon — slider ghi thang vao day */
    var grade: GradeState = GradeState()

    /** Tang khi CA BO gia tri doi, buoc slider doc lai */
    var rev by mutableIntStateOf(0)

    /** Thong bao loi tu pipeline GL / player */
    var status by mutableStateOf<String?>(null)

    /** Tom tat tuy chon xuat, hien o thanh tren */
    var exportSummary by mutableStateOf("HEVC 10-bit")

    // ---- Cac hanh dong do MainActivity gan vao ----
    var onPickVideo: () -> Unit = {}
    var onPickLuts: () -> Unit = {}
    var onExport: () -> Unit = {}
    var onExportAll: () -> Unit = {}
    var onApplyPreset: (Int) -> Unit = {}
    var onSelectClip: (Uri) -> Unit = {}
    var onCopyGrade: () -> Unit = {}
    var onPasteGrade: () -> Unit = {}
    var onPasteAll: () -> Unit = {}
    var onResetGrade: () -> Unit = {}
    var onGradeEdited: () -> Unit = {}      // sau moi lan slider doi
    var onSetKeyframe: (Boolean) -> Unit = {}   // true = KF dau, false = KF cuoi
    var onToggleKeyframes: () -> Unit = {}
    var keyframesEnabled: Boolean = false

    /** Goi khi ca bo gia tri doi (doi clip / ap preset / reset) */
    fun refreshAll() { rev++ }
}
